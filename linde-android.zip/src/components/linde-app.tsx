import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import {
  Download,
  Eye,
  EyeOff,
  FolderInput,
  FolderOutput,
  ImagePlus,
  Shield,
  Trash2,
} from "lucide-react";
import { classifyBlob, decide, labelFor, loadLocalModel } from "@/lib/linde/classify";
import {
  checkVerifier,
  decryptBytes,
  deriveKey,
  encryptBytes,
  makeVerifier,
  packPayload,
  randomBytes,
  unpackPayload,
} from "@/lib/linde/crypto";
import {
  clearHandle,
  deletePrivate,
  deletePublic,
  listPrivate,
  listPublic,
  putPrivate,
  putPublic,
  readHandle,
  readSeen,
  readVaultMeta,
  wipeAll,
  writeHandle,
  writeSeen,
  writeVaultMeta,
} from "@/lib/linde/idb";
import { readSettings, writeSettings } from "@/lib/linde/settings";
import { defaultSettings, type LogLine, type PrivateRecord, type PublicRecord, type Settings } from "@/lib/linde/types";

type Phase = "boot" | "setup" | "locked" | "open";
type ModelState = "idle" | "loading" | "ready" | "error";

type PublicView = PublicRecord & { url: string };
type VaultView = {
  id: string;
  addedAt: number;
  bytes: number;
  name?: string;
  label?: string;
  url?: string;
  revealed: boolean;
};

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatWhen(at: number): string {
  return new Intl.DateTimeFormat("es", { hour: "2-digit", minute: "2-digit" }).format(at);
}

async function sampleLandscape(): Promise<File> {
  const canvas = document.createElement("canvas");
  canvas.width = 960;
  canvas.height = 640;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Sin lienzo");
  const sky = ctx.createLinearGradient(0, 0, 0, 420);
  sky.addColorStop(0, "#6f92a8");
  sky.addColorStop(1, "#e4d2b4");
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, 960, 640);
  ctx.fillStyle = "#3d5344";
  ctx.beginPath();
  ctx.moveTo(0, 390);
  ctx.lineTo(220, 250);
  ctx.lineTo(410, 360);
  ctx.lineTo(640, 200);
  ctx.lineTo(960, 340);
  ctx.lineTo(960, 640);
  ctx.lineTo(0, 640);
  ctx.fill();
  ctx.fillStyle = "#f4efe6";
  ctx.font = "600 64px Fraunces, Georgia, serif";
  ctx.fillText("Linde", 56, 120);
  ctx.font = "400 22px Outfit, sans-serif";
  ctx.fillText("Imagen de prueba · no sale del dispositivo", 56, 164);
  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob((value) => (value ? resolve(value) : reject(new Error("JPEG"))), "image/jpeg", 0.92);
  });
  return new File([blob], "prueba-linde.jpg", { type: "image/jpeg" });
}

async function ensurePermission(handle: FileSystemDirectoryHandle, write: boolean): Promise<boolean> {
  const mode = write ? "readwrite" : "read";
  const current = await handle.queryPermission({ mode });
  if (current === "granted") return true;
  const next = await handle.requestPermission({ mode });
  return next === "granted";
}

async function writeIntoFolder(dir: FileSystemDirectoryHandle, file: File): Promise<void> {
  const handle = await dir.getFileHandle(file.name, { create: true });
  const writable = await handle.createWritable();
  await writable.write(file);
  await writable.close();
}

export function LindeApp() {
  const [phase, setPhase] = useState<Phase>("boot");
  const [modelState, setModelState] = useState<ModelState>("idle");
  const [modelError, setModelError] = useState("");
  const [settings, setSettings] = useState<Settings>(defaultSettings);
  const [passphrase, setPassphrase] = useState("");
  const [passphraseAgain, setPassphraseAgain] = useState("");
  const [formError, setFormError] = useState("");
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState("Preparando el almacén local");
  const [publicItems, setPublicItems] = useState<PublicView[]>([]);
  const [vaultItems, setVaultItems] = useState<VaultView[]>([]);
  const [logs, setLogs] = useState<LogLine[]>([]);
  const [sourceName, setSourceName] = useState("");
  const [destName, setDestName] = useState("");
  const [dragging, setDragging] = useState(false);
  const [pane, setPane] = useState<"inicio" | "biblioteca" | "boveda" | "ajustes">("inicio");
  const [folder, setFolder] = useState<"entrada" | "biblioteca" | "boveda" | "registro" | null>(null);

  const keyRef = useRef<CryptoKey | null>(null);
  const settingsRef = useRef(settings);
  const sourceRef = useRef<FileSystemDirectoryHandle | null>(null);
  const destRef = useRef<FileSystemDirectoryHandle | null>(null);
  const pendingRef = useRef<File[]>([]);
  const scanningRef = useRef(false);
  const urlsRef = useRef<string[]>([]);
  settingsRef.current = settings;

  const pushLog = useCallback((text: string, kind: LogLine["kind"]) => {
    setLogs((current) => [
      { id: crypto.randomUUID(), at: Date.now(), text, kind },
      ...current,
    ].slice(0, 12));
  }, []);

  const rememberUrl = useCallback((url: string) => {
    urlsRef.current.push(url);
    return url;
  }, []);

  const releaseUrls = useCallback((urls: string[]) => {
    for (const url of urls) URL.revokeObjectURL(url);
    urlsRef.current = urlsRef.current.filter((url) => !urls.includes(url));
  }, []);

  const hydratePublic = useCallback(
    (rows: PublicRecord[]) => {
      setPublicItems((current) => {
        releaseUrls(current.map((item) => item.url));
        return rows
          .sort((a, b) => b.addedAt - a.addedAt)
          .map((row) => ({ ...row, url: rememberUrl(URL.createObjectURL(row.blob)) }));
      });
    },
    [rememberUrl, releaseUrls],
  );

  const hydrateVault = useCallback((rows: PrivateRecord[]) => {
    setVaultItems((current) => {
      releaseUrls(current.flatMap((item) => (item.url ? [item.url] : [])));
      return rows
        .sort((a, b) => b.addedAt - a.addedAt)
        .map((row) => ({
          id: row.id,
          addedAt: row.addedAt,
          bytes: row.bytes,
          revealed: false,
        }));
    });
  }, [releaseUrls]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [meta, photos, sealed, source, dest] = await Promise.all([
          readVaultMeta(),
          listPublic(),
          listPrivate(),
          readHandle("source"),
          readHandle("dest"),
        ]);
        if (cancelled) return;
        hydratePublic(photos);
        hydrateVault(sealed);
        sourceRef.current = source;
        destRef.current = dest;
        setSourceName(source?.name ?? "");
        setDestName(dest?.name ?? "");
        setPhase(meta ? "locked" : "setup");
        setSettings(readSettings());
        setStatus(meta ? "Bóveda cerrada" : "Crea una frase para la bóveda");
      } catch (error) {
        if (cancelled) return;
        setPhase("setup");
        setFormError(error instanceof Error ? error.message : "No se pudo leer el almacén");
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [hydratePublic, hydrateVault]);

  useEffect(() => {
    return () => {
      for (const url of urlsRef.current) URL.revokeObjectURL(url);
    };
  }, []);

  useEffect(() => {
    if (phase !== "open") return;
    let cancelled = false;
    setModelState("loading");
    loadLocalModel()
      .then(() => {
        if (cancelled) return;
        setModelState("ready");
        setStatus("Modelo local listo");
      })
      .catch((error: unknown) => {
        if (cancelled) return;
        setModelState("error");
        setModelError(error instanceof Error ? error.message : "No se pudo cargar el modelo");
      });
    return () => {
      cancelled = true;
    };
  }, [phase]);

  const ingestFiles = useCallback(
    async (files: File[], source?: FileSystemDirectoryHandle | null) => {
      const key = keyRef.current;
      if (!key) {
        pushLog("Desbloquea la bóveda antes de clasificar", "info");
        return;
      }
      if (modelState !== "ready") {
        pushLog("El modelo todavía se está preparando", "info");
        return;
      }
      const images = files.filter((file) => file.type.startsWith("image/") || /\.(jpe?g|png|webp|gif|bmp)$/i.test(file.name));
      if (images.length === 0) {
        pushLog("No había imágenes en la selección", "info");
        return;
      }
      setBusy(true);
      const currentSettings = settingsRef.current;
      let safeCount = 0;
      let vaultCount = 0;
      try {
        for (const file of images) {
          setStatus(`Clasificando ${file.name}`);
          const buffer = new Uint8Array(await file.arrayBuffer());
          const scores = await classifyBlob(file);
          const decision = decide(scores, currentSettings);
          if (decision.nsfw) {
            const packed = packPayload(
              { name: file.name, mime: file.type || "image/jpeg", scores },
              buffer,
            );
            const sealed = await encryptBytes(key, packed);
            await putPrivate({
              id: crypto.randomUUID(),
              addedAt: Date.now(),
              bytes: buffer.byteLength,
              iv: sealed.iv,
              data: sealed.data,
            });
            vaultCount += 1;
            pushLog("Imagen explícita cifrada con AES-256-GCM", "vault");
          } else {
            const record: PublicRecord = {
              id: crypto.randomUUID(),
              name: file.name,
              mime: file.type || "image/jpeg",
              addedAt: Date.now(),
              bytes: buffer.byteLength,
              scores,
              blob: new Blob([buffer], { type: file.type || "image/jpeg" }),
            };
            await putPublic(record);
            safeCount += 1;
            const top = decision.top;
            pushLog(
              `${file.name} → biblioteca · ${labelFor(top.className)} ${Math.round(top.probability * 100)}%`,
              "safe",
            );
            const dest = destRef.current;
            if (dest) {
              try {
                if (await ensurePermission(dest, true)) {
                  await writeIntoFolder(dest, file);
                }
              } catch {
                pushLog(`No se pudo copiar ${file.name} a la carpeta pública`, "error");
              }
            }
          }
          if (currentSettings.removeSource && source) {
            try {
              await source.removeEntry(file.name);
            } catch {
              pushLog(`No se pudo retirar ${file.name} del origen`, "error");
            }
          }
        }
        hydratePublic(await listPublic());
        hydrateVault(await listPrivate());
        setStatus(
          vaultCount > 0
            ? `${safeCount} a la biblioteca · ${vaultCount} a la bóveda`
            : `${safeCount} imagen${safeCount === 1 ? "" : "es"} en la biblioteca`,
        );
      } catch (error) {
        pushLog(error instanceof Error ? error.message : "Falló la clasificación", "error");
        setStatus("Clasificación interrumpida");
      } finally {
        setBusy(false);
      }
    },
    [hydratePublic, hydrateVault, modelState, pushLog],
  );

  const scanSource = useCallback(async () => {
    const dir = sourceRef.current;
    const key = keyRef.current;
    if (!dir || !key || modelState !== "ready" || scanningRef.current) return;
    scanningRef.current = true;
    try {
      const allowed = await ensurePermission(dir, settingsRef.current.removeSource);
      if (!allowed) {
        pushLog("Sin permiso para leer la carpeta vigilada", "error");
        return;
      }
      const seen = new Set(await readSeen());
      const fresh: File[] = [];
      const signatures: string[] = [];
      for await (const [name, handle] of dir.entries()) {
        if (handle.kind !== "file") continue;
        if (!/\.(jpe?g|png|webp|gif|bmp)$/i.test(name)) continue;
        const file = await (handle as FileSystemFileHandle).getFile();
        const signature = `${name}:${file.size}:${file.lastModified}`;
        if (seen.has(signature)) continue;
        fresh.push(file);
        signatures.push(signature);
      }
      if (fresh.length === 0) return;
      pushLog(
        `${fresh.length} imagen${fresh.length === 1 ? "" : "es"} nueva${fresh.length === 1 ? "" : "s"} en la carpeta`,
        "info",
      );
      await ingestFiles(fresh, settingsRef.current.removeSource ? dir : null);
      signatures.forEach((signature) => seen.add(signature));
      await writeSeen([...seen]);
    } catch (error) {
      pushLog(error instanceof Error ? error.message : "No se pudo vigilar la carpeta", "error");
    } finally {
      scanningRef.current = false;
    }
  }, [ingestFiles, modelState, pushLog]);

  useEffect(() => {
    if (phase !== "open" || modelState !== "ready" || pendingRef.current.length === 0) return;
    const batch = pendingRef.current.splice(0);
    void ingestFiles(batch);
  }, [ingestFiles, modelState, phase]);

  useEffect(() => {
    if (phase !== "open" || !settings.watch || modelState !== "ready") return;
    const tick = () => {
      if (document.visibilityState !== "visible") return;
      void scanSource();
    };
    tick();
    const id = window.setInterval(tick, 20000);
    document.addEventListener("visibilitychange", tick);
    return () => {
      window.clearInterval(id);
      document.removeEventListener("visibilitychange", tick);
    };
  }, [modelState, phase, scanSource, settings.watch]);

  function updateSettings(next: Settings) {
    setSettings(next);
    writeSettings(next);
  }

  async function createVault(event: FormEvent) {
    event.preventDefault();
    setFormError("");
    if (passphrase.length < 8) {
      setFormError("Usa al menos 8 caracteres.");
      return;
    }
    if (passphrase !== passphraseAgain) {
      setFormError("Las frases no coinciden.");
      return;
    }
    setBusy(true);
    try {
      const salt = randomBytes(16);
      const key = await deriveKey(passphrase, salt);
      const verifier = await makeVerifier(key);
      await writeVaultMeta({ salt, iv: verifier.iv, verifier: verifier.data });
      keyRef.current = key;
      setPassphrase("");
      setPassphraseAgain("");
      setPhase("open");
      setStatus("Bóveda creada en este dispositivo");
      pushLog("Clave derivada con PBKDF2 y comprobada. No se guarda la frase.", "info");
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "No se pudo crear la bóveda");
    } finally {
      setBusy(false);
    }
  }

  async function unlock(event: FormEvent) {
    event.preventDefault();
    setFormError("");
    setBusy(true);
    try {
      const meta = await readVaultMeta();
      if (!meta) {
        setPhase("setup");
        return;
      }
      const key = await deriveKey(passphrase, meta.salt);
      const ok = await checkVerifier(key, meta.iv, meta.verifier);
      if (!ok) {
        setFormError("Frase incorrecta.");
        return;
      }
      keyRef.current = key;
      setPassphrase("");
      setPhase("open");
      setStatus("Bóveda abierta en memoria");
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "No se pudo abrir");
    } finally {
      setBusy(false);
    }
  }

  function lock() {
    keyRef.current = null;
    setVaultItems((current) => {
      releaseUrls(current.flatMap((item) => (item.url ? [item.url] : [])));
      return current.map((item) => ({
        id: item.id,
        addedAt: item.addedAt,
        bytes: item.bytes,
        revealed: false,
      }));
    });
    setPhase("locked");
    setStatus("Bóveda cerrada. La clave ya no está en memoria.");
  }

  async function pickFolder(kind: "source" | "dest") {
    const picker = window.showDirectoryPicker;
    if (!picker) {
      pushLog("Este navegador no deja elegir carpetas. Arrastra las fotos.", "info");
      return;
    }
    try {
      const handle = await picker({
        mode: kind === "dest" || settings.removeSource ? "readwrite" : "read",
        id: kind === "source" ? "linde-source" : "linde-dest",
      });
      await writeHandle(kind, handle);
      if (kind === "source") {
        sourceRef.current = handle;
        setSourceName(handle.name);
        pushLog(`Vigilando “${handle.name}”`, "info");
        if (phase === "open") void scanSource();
      } else {
        destRef.current = handle;
        setDestName(handle.name);
        pushLog(`Las fotos neutras también se copian a “${handle.name}”`, "info");
      }
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
      pushLog(error instanceof Error ? error.message : "No se pudo elegir la carpeta", "error");
    }
  }

  async function forgetFolder(kind: "source" | "dest") {
    await clearHandle(kind);
    if (kind === "source") {
      sourceRef.current = null;
      setSourceName("");
    } else {
      destRef.current = null;
      setDestName("");
    }
  }

  async function onPickFiles(list: FileList | File[] | null) {
    if (!list) return;
    const batch = Array.from(list);
    if (phase !== "open" || !keyRef.current) {
      pushLog("Desbloquea la bóveda para clasificar", "info");
      return;
    }
    if (modelState !== "ready") {
      pendingRef.current.push(...batch);
      pushLog("En cola. Empieza sola cuando el modelo local esté listo.", "info");
      return;
    }
    await ingestFiles(batch);
  }

  async function runSample() {
    if (phase !== "open") return;
    const file = await sampleLandscape();
    await ingestFiles([file]);
  }

  async function removePublic(item: PublicView) {
    URL.revokeObjectURL(item.url);
    await deletePublic(item.id);
    setPublicItems((current) => current.filter((row) => row.id !== item.id));
  }

  function downloadPublic(item: PublicView) {
    const anchor = document.createElement("a");
    anchor.href = item.url;
    anchor.download = item.name;
    anchor.click();
  }

  async function toggleVault(item: VaultView) {
    if (item.url) {
      setVaultItems((current) =>
        current.map((row) => (row.id === item.id ? { ...row, revealed: !row.revealed } : row)),
      );
      return;
    }
    const key = keyRef.current;
    if (!key) return;
    const rows = await listPrivate();
    const row = rows.find((candidate) => candidate.id === item.id);
    if (!row) return;
    try {
      const plain = await decryptBytes(key, row.iv, row.data);
      const unpacked = unpackPayload(plain);
      const blob = new Blob([new Uint8Array(unpacked.image)], { type: unpacked.meta.mime });
      const url = rememberUrl(URL.createObjectURL(blob));
      const top = [...unpacked.meta.scores].sort((a, b) => b.probability - a.probability)[0];
      setVaultItems((current) =>
        current.map((entry) =>
          entry.id === item.id
            ? {
                ...entry,
                url,
                name: unpacked.meta.name,
                label: top ? labelFor(top.className) : "Cifrada",
                revealed: true,
              }
            : entry,
        ),
      );
    } catch {
      pushLog("No se pudo descifrar esa entrada", "error");
    }
  }

  async function removeVault(id: string) {
    const current = vaultItems.find((item) => item.id === id);
    if (current?.url) URL.revokeObjectURL(current.url);
    await deletePrivate(id);
    setVaultItems((rows) => rows.filter((row) => row.id !== id));
  }

  async function eraseEverything() {
    const confirmed = window.confirm(
      "Esto borra la frase, la biblioteca y la bóveda de este navegador. No se puede deshacer.",
    );
    if (!confirmed) return;
    await wipeAll();
    keyRef.current = null;
    sourceRef.current = null;
    destRef.current = null;
    releaseUrls(urlsRef.current.slice());
    setPublicItems([]);
    setVaultItems([]);
    setLogs([]);
    setSourceName("");
    setDestName("");
    setPhase("setup");
    setStatus("Almacén local vacío");
  }

  const counts = useMemo(
    () => ({ public: publicItems.length, vault: vaultItems.length }),
    [publicItems.length, vaultItems.length],
  );

  const screen =
    pane === "ajustes"
      ? "ajustes"
      : pane === "biblioteca"
        ? "biblioteca"
        : pane === "boveda"
          ? "boveda"
          : (folder ?? "grid");

  return (
    <div className="relative min-h-dvh">
      <div className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
        <div className="absolute -top-20 -left-10 size-72 rounded-full bg-orb-blue/50" />
        <div className="absolute top-40 -right-16 size-64 rounded-full bg-orb-copper/45" />
        <div className="absolute bottom-8 left-8 size-56 rounded-full bg-orb-green/40" />
      </div>
      <div className="glass relative min-h-dvh border-0">
        <main className="mx-auto min-h-dvh max-w-5xl px-4 pt-8 pb-32 sm:px-6">
          <header className="flex items-end justify-between gap-4">
            <div>
              <p className="text-xs tracking-widest text-muted uppercase">Archivo local</p>
              <h1 className="font-display text-4xl font-medium tracking-tight">Linde</h1>
            </div>
            <p className="max-w-xs text-right text-sm text-muted">{status}</p>
          </header>

          {screen === "grid" ? (
            <section className="mt-8" aria-label="Carpetas">
              <h2 className="text-sm text-muted">Elige una carpeta</h2>
              <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
                <FolderCard name="Entrada" detail="Clasificar" count={null} onOpen={() => setFolder("entrada")} />
                <FolderCard
                  name="Biblioteca"
                  detail="Públicas"
                  count={counts.public}
                  onOpen={() => setFolder("biblioteca")}
                />
                <FolderCard name="Bóveda" detail="Cifradas" count={counts.vault} onOpen={() => setFolder("boveda")} />
                <FolderCard
                  name="Registro"
                  detail="Movimientos"
                  count={logs.length}
                  onOpen={() => setFolder("registro")}
                />
              </ul>
            </section>
          ) : (
            <div className="mt-6">
              {pane === "inicio" ? (
                <button type="button" onClick={() => setFolder(null)} className="mb-4 h-11 text-sm text-muted">
                  Inicio
                </button>
              ) : null}

              {screen === "entrada" ? (
                <section className="glass rounded-card p-4 text-fg sm:p-5">
                  <h2 className="font-display text-2xl">Entrada</h2>
                  <p className="mt-2 text-sm text-muted">
                    Suelta fotos. Lo neutro queda en la biblioteca. Lo explícito se cifra.
                  </p>
                  {phase === "boot" ? <p className="mt-6 text-sm">Abriendo el almacén…</p> : null}
                  {phase === "setup" ? (
                    <form className="mt-5 grid gap-3" onSubmit={createVault}>
                      <Field
                        label="Frase de la bóveda"
                        value={passphrase}
                        onChange={setPassphrase}
                        autoComplete="new-password"
                      />
                      <Field
                        label="Repite la frase"
                        value={passphraseAgain}
                        onChange={setPassphraseAgain}
                        autoComplete="new-password"
                      />
                      {formError ? <p className="text-sm text-copper">{formError}</p> : null}
                      <button
                        type="submit"
                        disabled={busy}
                        className="inline-flex h-12 items-center justify-center rounded-2xl bg-fg px-4 text-sm font-medium text-bg disabled:opacity-60"
                      >
                        Crear bóveda
                      </button>
                    </form>
                  ) : null}
                  {phase === "locked" ? (
                    <form className="mt-5 grid gap-3" onSubmit={unlock}>
                      <Field label="Frase" value={passphrase} onChange={setPassphrase} autoComplete="current-password" />
                      {formError ? <p className="text-sm text-copper">{formError}</p> : null}
                      <button
                        type="submit"
                        disabled={busy}
                        className="inline-flex h-12 items-center justify-center rounded-2xl bg-fg px-4 text-sm font-medium text-bg disabled:opacity-60"
                      >
                        Abrir para clasificar
                      </button>
                    </form>
                  ) : null}
                  {phase === "open" ? (
                    <div className="mt-5 grid gap-3">
                      <label
                        onDragOver={(event) => {
                          event.preventDefault();
                          setDragging(true);
                        }}
                        onDragLeave={() => setDragging(false)}
                        onDrop={(event) => {
                          event.preventDefault();
                          setDragging(false);
                          void onPickFiles(event.dataTransfer.files);
                        }}
                        className={
                          "flex min-h-28 cursor-pointer flex-col items-center justify-center gap-2 rounded-card border border-dashed px-3 py-4 text-center text-sm " +
                          (dragging ? "border-fg" : "border-line")
                        }
                      >
                        <ImagePlus className="size-5" aria-hidden="true" />
                        <span>Arrastra imágenes o elige archivos</span>
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          className="sr-only"
                          onChange={(event) => {
                            void onPickFiles(event.target.files);
                            event.target.value = "";
                          }}
                        />
                      </label>
                      <div className="grid gap-2 sm:grid-cols-2">
                        <button
                          type="button"
                          onClick={() => void runSample()}
                          disabled={busy || modelState !== "ready"}
                          className="inline-flex h-11 items-center justify-center rounded-2xl bg-sage px-3 text-sm font-medium text-sage-ink disabled:opacity-60"
                        >
                          Probar con un paisaje
                        </button>
                        <button
                          type="button"
                          onClick={() => void scanSource()}
                          disabled={busy || !sourceName || modelState !== "ready"}
                          className="inline-flex h-11 items-center justify-center rounded-2xl border border-line px-3 text-sm font-medium disabled:opacity-50"
                        >
                          Revisar carpeta
                        </button>
                      </div>
                      {modelState === "error" ? <p className="text-sm text-copper">{modelError}</p> : null}
                      <button type="button" onClick={lock} className="inline-flex h-11 items-center justify-center text-sm text-muted">
                        Cerrar bóveda
                      </button>
                    </div>
                  ) : null}
                </section>
              ) : null}

              {screen === "biblioteca" ? (
                <section>
                  <h2 className="font-display text-2xl">Biblioteca</h2>
                  <p className="mt-1 text-sm text-muted">Fotos que no superaron el umbral.</p>
                  {publicItems.length === 0 ? (
                    <p className="mt-4 text-sm text-muted">Todavía no hay fotos públicas.</p>
                  ) : (
                    <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                      {publicItems.map((item) => (
                        <li key={item.id} className="glass overflow-hidden rounded-card">
                          <img src={item.url} alt={item.name} className="aspect-square w-full object-cover" />
                          <div className="grid gap-2 p-3">
                            <p className="truncate text-sm">{item.name}</p>
                            <p className="text-xs text-muted">
                              {labelFor(item.scores[0]?.className ?? "Neutral")} · {formatBytes(item.bytes)}
                            </p>
                            <div className="flex gap-2">
                              <IconButton label={`Descargar ${item.name}`} onClick={() => downloadPublic(item)}>
                                <Download className="size-4" />
                              </IconButton>
                              <IconButton label={`Quitar ${item.name}`} onClick={() => void removePublic(item)}>
                                <Trash2 className="size-4" />
                              </IconButton>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>
              ) : null}

              {screen === "boveda" ? (
                <section>
                  <h2 className="font-display text-2xl">Bóveda</h2>
                  <p className="mt-1 text-sm text-muted">AES-256-GCM. El nombre va dentro del cifrado.</p>
                  {vaultItems.length === 0 ? (
                    <p className="mt-4 text-sm text-muted">La bóveda está vacía.</p>
                  ) : (
                    <ul className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3">
                      {vaultItems.map((item) => (
                        <li key={item.id} className="glass overflow-hidden rounded-card">
                          <div className="relative aspect-square">
                            {item.url ? (
                              <img
                                src={item.url}
                                alt={item.revealed ? (item.name ?? "Imagen cifrada") : ""}
                                className={"aspect-square w-full object-cover " + (item.revealed ? "" : "scale-110 blur-xl")}
                              />
                            ) : (
                              <div className="flex h-full items-center justify-center">
                                <Shield className="size-6 text-copper" aria-hidden="true" />
                              </div>
                            )}
                          </div>
                          <div className="grid gap-2 p-3">
                            <p className="truncate text-sm">{item.revealed ? item.name : "Cifrada"}</p>
                            <p className="text-xs text-muted">
                              {item.label ?? "Sin descifrar"} · {formatBytes(item.bytes)}
                            </p>
                            <div className="flex gap-2">
                              <IconButton
                                label={item.revealed ? "Ocultar imagen" : "Descifrar y mostrar"}
                                onClick={() => void toggleVault(item)}
                                disabled={phase !== "open"}
                              >
                                {item.revealed ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                              </IconButton>
                              <IconButton label="Borrar de la bóveda" onClick={() => void removeVault(item.id)}>
                                <Trash2 className="size-4" />
                              </IconButton>
                            </div>
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>
              ) : null}

              {screen === "registro" ? (
                <section>
                  <h2 className="font-display text-2xl">Registro</h2>
                  {logs.length === 0 ? (
                    <p className="mt-2 text-sm text-muted">Las explícitas no muestran el nombre.</p>
                  ) : (
                    <ul className="mt-4 grid gap-2">
                      {logs.map((line) => (
                        <li key={line.id} className="glass flex items-baseline justify-between gap-3 rounded-2xl px-3 py-3 text-sm">
                          <span
                            className={
                              line.kind === "vault" || line.kind === "error"
                                ? "text-copper"
                                : line.kind === "safe"
                                  ? "text-sage"
                                  : "text-fg"
                            }
                          >
                            {line.text}
                          </span>
                          <time className="shrink-0 text-xs text-muted" dateTime={new Date(line.at).toISOString()}>
                            {formatWhen(line.at)}
                          </time>
                        </li>
                      ))}
                    </ul>
                  )}
                </section>
              ) : null}

              {screen === "ajustes" ? (
                <section className="grid gap-4 text-sm">
                  <h2 className="font-display text-2xl">Ajustes</h2>
                  <div className="glass grid gap-3 rounded-card p-4">
                    <FolderRow
                      icon={<FolderInput className="size-4" aria-hidden="true" />}
                      title="Carpeta vigilada"
                      name={sourceName}
                      onPick={() => void pickFolder("source")}
                      onClear={sourceName ? () => void forgetFolder("source") : undefined}
                    />
                    <FolderRow
                      icon={<FolderOutput className="size-4" aria-hidden="true" />}
                      title="Copia pública"
                      name={destName}
                      onPick={() => void pickFolder("dest")}
                      onClear={destName ? () => void forgetFolder("dest") : undefined}
                    />
                    <label className="grid gap-1">
                      <span className="flex items-center justify-between">
                        Umbral explícito
                        <span className="tabular-nums">{Math.round(settings.threshold * 100)}%</span>
                      </span>
                      <input
                        type="range"
                        min={0.15}
                        max={0.9}
                        step={0.05}
                        value={settings.threshold}
                        onChange={(event) => updateSettings({ ...settings, threshold: Number(event.target.value) })}
                      />
                    </label>
                    <Toggle
                      checked={settings.treatSexy}
                      label="Cifrar también si domina “sugerente”"
                      onChange={(treatSexy) => updateSettings({ ...settings, treatSexy })}
                    />
                    <Toggle
                      checked={settings.watch}
                      label="Revisar al abrir y con la pestaña visible"
                      onChange={(watch) => updateSettings({ ...settings, watch })}
                    />
                    <Toggle
                      checked={settings.removeSource}
                      label="Retirar del origen después de clasificar"
                      onChange={(removeSource) => updateSettings({ ...settings, removeSource })}
                    />
                  </div>
                  <p className="text-muted">
                    En Android el mismo vidrio está en el proyecto Flutter, con{" "}
                    <span className="text-fg">cupertino_liquid_glass</span>.{" "}
                    <a className="text-sage underline underline-offset-2" href="/linde-android.zip" download>
                      Descargar
                    </a>
                  </p>
                  <button type="button" onClick={() => void eraseEverything()} className="h-11 text-left text-copper">
                    Borrar la bóveda de este navegador
                  </button>
                </section>
              ) : null}
            </div>
          )}
        </main>
      </div>
      <nav
        className="glass-bar fixed inset-x-3 bottom-3 z-10 mx-auto flex max-w-lg items-stretch justify-between rounded-full px-2 py-1"
        aria-label="Secciones"
      >
        <BarButton
          active={pane === "inicio" && screen === "grid"}
          label="Inicio"
          onClick={() => {
            setPane("inicio");
            setFolder(null);
          }}
        />
        <BarButton
          active={screen === "biblioteca"}
          label="Biblioteca"
          onClick={() => {
            setPane("biblioteca");
            setFolder(null);
          }}
        />
        <BarButton
          active={screen === "boveda"}
          label="Bóveda"
          onClick={() => {
            setPane("boveda");
            setFolder(null);
          }}
        />
        <BarButton
          active={screen === "ajustes"}
          label="Ajustes"
          onClick={() => {
            setPane("ajustes");
            setFolder(null);
          }}
        />
      </nav>
    </div>
  );
}

function FolderCard({
  name,
  detail,
  count,
  onOpen,
}: {
  name: string;
  detail: string;
  count: number | null;
  onOpen: () => void;
}) {
  return (
    <li>
      <button
        type="button"
        onClick={onOpen}
        className="glass flex aspect-square w-full flex-col items-start justify-between rounded-card p-4 text-left"
      >
        <span className="text-xs tracking-wide text-muted uppercase">{detail}</span>
        <span>
          <span className="block text-xl font-medium">{name}</span>
          <span className="text-sm text-muted">{count === null ? "Abrir" : count}</span>
        </span>
      </button>
    </li>
  );
}

function BarButton({ active, label, onClick }: { active: boolean; label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        "flex h-14 min-w-16 flex-1 flex-col items-center justify-center rounded-full text-xs " +
        (active ? "bg-fg/10 font-medium text-fg" : "text-muted")
      }
    >
      {label}
    </button>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: "sage" | "copper" | "neutral" }) {
  const valueClass = tone === "sage" ? "text-sage" : tone === "copper" ? "text-copper" : "text-fg";
  return (
    <div className="rounded-card border border-line bg-surface px-3 py-3">
      <p className="text-xs tracking-wide text-muted uppercase">{label}</p>
      <p className={`mt-1 font-display text-3xl leading-none ${valueClass}`}>{value}</p>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  autoComplete,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  autoComplete: string;
}) {
  return (
    <label className="grid gap-1 text-sm">
      {label}
      <input
        type="password"
        value={value}
        autoComplete={autoComplete}
        onChange={(event) => onChange(event.target.value)}
        className="h-12 rounded-2xl border border-line bg-bg/40 px-3 text-fg"
      />
    </label>
  );
}

function Toggle({
  checked,
  label,
  onChange,
}: {
  checked: boolean;
  label: string;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex items-start gap-3">
      <input
        type="checkbox"
        checked={checked}
        onChange={(event) => onChange(event.target.checked)}
        className="mt-1 size-4 accent-sage"
      />
      <span>{label}</span>
    </label>
  );
}

function FolderRow({
  icon,
  title,
  name,
  onPick,
  onClear,
}: {
  icon: ReactNode;
  title: string;
  name: string;
  onPick: () => void;
  onClear?: () => void;
}) {
  return (
    <div className="flex items-center justify-between gap-2">
      <div className="min-w-0">
        <p className="flex items-center gap-2 font-medium text-fg">
          {icon}
          {title}
        </p>
        <p className="truncate text-muted">{name || "Sin elegir"}</p>
      </div>
      <div className="flex shrink-0 gap-2">
        <button type="button" onClick={onPick} className="h-11 rounded-2xl border border-line px-3 text-fg">
          Elegir
        </button>
        {onClear ? (
          <button type="button" onClick={onClear} className="h-11 px-2 text-muted">
            Quitar
          </button>
        ) : null}
      </div>
    </div>
  );
}

function Panel({
  title,
  hint,
  empty,
  emptyText,
  children,
}: {
  title: string;
  hint: string;
  empty: boolean;
  emptyText: string;
  children: ReactNode;
}) {
  return (
    <section className="rounded-card border border-line bg-surface p-4">
      <h2 className="font-display text-2xl">{title}</h2>
      <p className="mt-1 text-sm text-muted">{hint}</p>
      <div className="mt-4">{empty ? <p className="text-sm text-muted">{emptyText}</p> : children}</div>
    </section>
  );
}

function IconButton({
  label,
  onClick,
  disabled,
  light,
  children,
}: {
  label: string;
  onClick: () => void;
  disabled?: boolean;
  light?: boolean;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      disabled={disabled}
      onClick={onClick}
      className={
        "inline-flex size-11 items-center justify-center rounded-md disabled:opacity-40 " +
        (light ? "bg-paper/10 text-paper" : "bg-bg text-fg")
      }
    >
      {children}
    </button>
  );
}
