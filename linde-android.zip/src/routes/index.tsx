import { createFileRoute } from "@tanstack/react-router";
import { LindeApp } from "@/components/linde-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <LindeApp />;
}
