import type { FolderKind, PrivateRecord, PublicRecord, VaultMeta } from "@/lib/linde/types";

const DB_NAME = "linde";
const DB_VERSION = 1;

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta");
      if (!db.objectStoreNames.contains("public")) {
        db.createObjectStore("public", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("private")) {
        db.createObjectStore("private", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("handles")) db.createObjectStore("handles");
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("No se pudo abrir el almacén local"));
  });
}

async function withStore<T>(
  name: "meta" | "public" | "private" | "handles",
  mode: IDBTransactionMode,
  run: (store: IDBObjectStore) => IDBRequest<T>,
): Promise<T> {
  const db = await openDb();
  try {
    const tx = db.transaction(name, mode);
    const store = tx.objectStore(name);
    const request = run(store);
    return await new Promise<T>((resolve, reject) => {
      tx.oncomplete = () => resolve(request.result);
      tx.onabort = () => reject(tx.error ?? request.error ?? new Error("Transacción abortada"));
      tx.onerror = () => reject(tx.error ?? request.error ?? new Error("Transacción fallida"));
    });
  } finally {
    db.close();
  }
}

export function readVaultMeta(): Promise<VaultMeta | null> {
  return withStore<VaultMeta | undefined>("meta", "readonly", (store) => store.get("vault")).then(
    (row) => row ?? null,
  );
}

export function writeVaultMeta(meta: VaultMeta): Promise<IDBValidKey> {
  return withStore("meta", "readwrite", (store) => store.put(meta, "vault"));
}

export function readSeen(): Promise<string[]> {
  return withStore<string[] | undefined>("meta", "readonly", (store) => store.get("seen")).then(
    (row) => row ?? [],
  );
}

export function writeSeen(seen: string[]): Promise<IDBValidKey> {
  return withStore("meta", "readwrite", (store) => store.put(seen.slice(-400), "seen"));
}

export function listPublic(): Promise<PublicRecord[]> {
  return withStore("public", "readonly", (store) => store.getAll());
}

export function putPublic(record: PublicRecord): Promise<IDBValidKey> {
  return withStore("public", "readwrite", (store) => store.put(record));
}

export function deletePublic(id: string): Promise<undefined> {
  return withStore("public", "readwrite", (store) => store.delete(id));
}

export function listPrivate(): Promise<PrivateRecord[]> {
  return withStore("private", "readonly", (store) => store.getAll());
}

export function putPrivate(record: PrivateRecord): Promise<IDBValidKey> {
  return withStore("private", "readwrite", (store) => store.put(record));
}

export function deletePrivate(id: string): Promise<undefined> {
  return withStore("private", "readwrite", (store) => store.delete(id));
}

export function readHandle(kind: FolderKind): Promise<FileSystemDirectoryHandle | null> {
  return withStore<FileSystemDirectoryHandle | undefined>("handles", "readonly", (store) =>
    store.get(kind),
  ).then((row) => row ?? null);
}

export function writeHandle(kind: FolderKind, handle: FileSystemDirectoryHandle): Promise<IDBValidKey> {
  return withStore("handles", "readwrite", (store) => store.put(handle, kind));
}

export function clearHandle(kind: FolderKind): Promise<undefined> {
  return withStore("handles", "readwrite", (store) => store.delete(kind));
}

export async function wipeAll(): Promise<void> {
  const db = await openDb();
  try {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(["meta", "public", "private", "handles"], "readwrite");
      tx.objectStore("meta").clear();
      tx.objectStore("public").clear();
      tx.objectStore("private").clear();
      tx.objectStore("handles").clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("No se pudo borrar"));
      tx.onabort = () => reject(tx.error ?? new Error("No se pudo borrar"));
    });
  } finally {
    db.close();
  }
}
