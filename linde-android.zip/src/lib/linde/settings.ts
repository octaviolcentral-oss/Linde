import { defaultSettings, type Settings } from "@/lib/linde/types";

const KEY = "linde-settings";

export function readSettings(): Settings {
  if (typeof localStorage === "undefined") return defaultSettings;
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultSettings;
    const parsed = JSON.parse(raw) as Partial<Settings>;
    return {
      threshold:
        typeof parsed.threshold === "number"
          ? Math.min(0.9, Math.max(0.15, parsed.threshold))
          : defaultSettings.threshold,
      treatSexy: Boolean(parsed.treatSexy),
      removeSource: Boolean(parsed.removeSource),
      watch: parsed.watch !== false,
    };
  } catch {
    return defaultSettings;
  }
}

export function writeSettings(settings: Settings): void {
  localStorage.setItem(KEY, JSON.stringify(settings));
}
