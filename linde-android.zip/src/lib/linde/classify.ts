import type { Score, Settings } from "@/lib/linde/types";

export type Decision = {
  scores: Score[];
  explicit: number;
  sexy: number;
  top: Score;
  nsfw: boolean;
  label: string;
};

type Model = {
  classify: (
    img: HTMLCanvasElement,
    topk?: number,
  ) => Promise<Array<{ className: string; probability: number }>>;
};

let loading: Promise<Model> | null = null;

/** MobileNetV2 de nsfwjs, pesos incluidos en el paquete. No hay red. */
export function loadLocalModel(): Promise<Model> {
  if (typeof window === "undefined") {
    return Promise.reject(new Error("El modelo solo corre en el navegador"));
  }
  if (!loading) {
    loading = (async () => {
      const tf = await import("@tensorflow/tfjs");
      await tf.ready();
      try {
        await tf.setBackend("webgl");
        await tf.ready();
      } catch {
        await tf.setBackend("cpu");
        await tf.ready();
      }
      const core = await import("nsfwjs/core");
      const mobilenet = await import("nsfwjs/models/mobilenet_v2");
      return core.load("MobileNetV2", {
        modelDefinitions: [mobilenet.MobileNetV2Model],
      });
    })().catch((error: unknown) => {
      loading = null;
      throw error;
    });
  }
  return loading;
}

async function toCanvas(file: Blob): Promise<HTMLCanvasElement> {
  const bitmap = await createImageBitmap(file);
  const canvas = document.createElement("canvas");
  const maxEdge = 512;
  const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
  canvas.width = Math.max(1, Math.round(bitmap.width * scale));
  canvas.height = Math.max(1, Math.round(bitmap.height * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) {
    bitmap.close();
    throw new Error("No se pudo preparar la imagen");
  }
  ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return canvas;
}

const LABELS: Record<string, string> = {
  Drawing: "Dibujo",
  Hentai: "Ilustración explícita",
  Neutral: "Neutra",
  Porn: "Explícita",
  Sexy: "Sugerente",
};

export function labelFor(className: string): string {
  return LABELS[className] ?? className;
}

export async function classifyBlob(file: Blob): Promise<Score[]> {
  const model = await loadLocalModel();
  const canvas = await toCanvas(file);
  const predictions = await model.classify(canvas, 5);
  return predictions.map((item) => ({
    className: item.className,
    probability: item.probability,
  }));
}

export function decide(scores: Score[], settings: Settings): Decision {
  const byName = Object.fromEntries(scores.map((score) => [score.className, score.probability]));
  const explicit = (byName.Porn ?? 0) + (byName.Hentai ?? 0);
  const sexy = byName.Sexy ?? 0;
  const top = [...scores].sort((a, b) => b.probability - a.probability)[0] ?? {
    className: "Neutral",
    probability: 0,
  };
  const sexyWins = settings.treatSexy && top.className === "Sexy" && sexy >= settings.threshold;
  const nsfw = explicit >= settings.threshold || sexyWins;
  return {
    scores,
    explicit,
    sexy,
    top,
    nsfw,
    label: labelFor(top.className),
  };
}
