import type { Score } from "@/lib/linde/types";

const VERIFIER_TEXT = "linde-vault-v1";
const ITERATIONS = 210_000;

function copyBuffer(bytes: Uint8Array): ArrayBuffer {
  const copy = new Uint8Array(bytes.byteLength);
  copy.set(bytes);
  return copy.buffer;
}

export function randomBytes(length: number): Uint8Array {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  return bytes;
}

export async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(passphrase),
    "PBKDF2",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    {
      name: "PBKDF2",
      salt: copyBuffer(salt),
      iterations: ITERATIONS,
      hash: "SHA-256",
    },
    base,
    { name: "AES-GCM", length: 256 },
    false,
    ["encrypt", "decrypt"],
  );
}

export async function encryptBytes(
  key: CryptoKey,
  plain: Uint8Array,
): Promise<{ iv: Uint8Array; data: Uint8Array }> {
  const iv = randomBytes(12);
  const cipher = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: copyBuffer(iv) },
    key,
    copyBuffer(plain),
  );
  return { iv, data: new Uint8Array(cipher) };
}

export async function decryptBytes(key: CryptoKey, iv: Uint8Array, data: Uint8Array): Promise<Uint8Array> {
  const plain = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: copyBuffer(iv) },
    key,
    copyBuffer(data),
  );
  return new Uint8Array(plain);
}

export async function makeVerifier(key: CryptoKey): Promise<{ iv: Uint8Array; data: Uint8Array }> {
  return encryptBytes(key, new TextEncoder().encode(VERIFIER_TEXT));
}

export async function checkVerifier(key: CryptoKey, iv: Uint8Array, data: Uint8Array): Promise<boolean> {
  try {
    const plain = await decryptBytes(key, iv, data);
    return new TextDecoder().decode(plain) === VERIFIER_TEXT;
  } catch {
    return false;
  }
}

export type PayloadMeta = {
  name: string;
  mime: string;
  scores: Score[];
};

/** Cabecera JSON + bytes de la imagen. El paquete entero se cifra; el nombre no queda en claro. */
export function packPayload(meta: PayloadMeta, image: Uint8Array): Uint8Array {
  const header = new TextEncoder().encode(JSON.stringify(meta));
  const out = new Uint8Array(4 + header.length + image.length);
  new DataView(out.buffer).setUint32(0, header.length, false);
  out.set(header, 4);
  out.set(image, 4 + header.length);
  return out;
}

export function unpackPayload(packet: Uint8Array): { meta: PayloadMeta; image: Uint8Array } {
  const view = new DataView(packet.buffer, packet.byteOffset, packet.byteLength);
  const headerLength = view.getUint32(0, false);
  const header = packet.slice(4, 4 + headerLength);
  const image = packet.slice(4 + headerLength);
  const meta = JSON.parse(new TextDecoder().decode(header)) as PayloadMeta;
  return { meta, image };
}
