export type Score = {
  className: string;
  probability: number;
};

export type Settings = {
  /** Suma Porn + Hentai a partir de la cual la imagen va a la bóveda. */
  threshold: number;
  /** Si la clase dominante es Sexy y supera el umbral, también se cifra. */
  treatSexy: boolean;
  /** Borra el archivo de la carpeta vigilada tras copiarlo. */
  removeSource: boolean;
  /** Revisa la carpeta al abrir y mientras la pestaña está visible. */
  watch: boolean;
};

export const defaultSettings: Settings = {
  threshold: 0.4,
  treatSexy: false,
  removeSource: false,
  watch: true,
};

export type PublicRecord = {
  id: string;
  name: string;
  mime: string;
  addedAt: number;
  bytes: number;
  scores: Score[];
  blob: Blob;
};

export type PrivateRecord = {
  id: string;
  addedAt: number;
  bytes: number;
  iv: Uint8Array;
  data: Uint8Array;
};

export type VaultMeta = {
  salt: Uint8Array;
  iv: Uint8Array;
  verifier: Uint8Array;
};

export type LogKind = "safe" | "vault" | "info" | "error";

export type LogLine = {
  id: string;
  at: number;
  text: string;
  kind: LogKind;
};

export type FolderKind = "source" | "dest";
