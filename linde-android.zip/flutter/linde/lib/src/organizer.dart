import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/widgets.dart';
import 'package:flutter/services.dart';
import 'package:nsfw_detector_flutter/nsfw_detector_flutter.dart';

/// Puente con Android: carpetas (SAF o Descargas), cifrado Keystore y ajustes.
class LindeOs {
  LindeOs({MethodChannel? channel}) : channel = channel ?? const MethodChannel('com.linde/os');

  final MethodChannel channel;

  Future<Map<String, dynamic>> prefs() async {
    final raw = await channel.invokeMapMethod<String, dynamic>('getPrefs');
    return raw ?? <String, dynamic>{};
  }

  Future<void> setPrefs(Map<String, Object?> values) {
    return channel.invokeMethod('setPrefs', values);
  }

  Future<List<String>> album(String which) async {
    return await channel.invokeListMethod<String>('listAlbum', {'which': which}) ?? const [];
  }

  Future<String?> pickTree({required bool destination}) {
    return channel.invokeMethod<String>('pickTree', {'destination': destination});
  }

  Future<void> useDownloads() {
    return channel.invokeMethod('useDownloads');
  }

  Future<bool> hasAllFiles() async {
    return await channel.invokeMethod<bool>('hasAllFiles') ?? false;
  }

  Future<void> openAllFilesSettings() {
    return channel.invokeMethod('openAllFilesSettings');
  }

  Future<void> startWatcher() {
    return channel.invokeMethod('startWatcher');
  }

  Future<void> stopWatcher() {
    return channel.invokeMethod('stopWatcher');
  }

  Future<List<Map<String, dynamic>>> listVault() async {
    final rows = await channel.invokeListMethod<dynamic>('listVault') ?? const [];
    return rows.map((row) => Map<String, dynamic>.from(row as Map)).toList();
  }

  Future<Uint8List> decryptVault(String id) async {
    final bytes = await channel.invokeMethod<Uint8List>('decryptVault', {'id': id});
    if (bytes == null) {
      throw StateError('No se pudo descifrar');
    }
    return bytes;
  }

  Future<void> deleteVault(String id) {
    return channel.invokeMethod('deleteVault', {'id': id});
  }
}

class LindeOrganizer {
  LindeOrganizer({LindeOs? os}) : os = os ?? LindeOs();

  final LindeOs os;
  var _ready = false;

  Future<void> ensureModel() async {
    if (_ready) return;
    // open_nsfw corre en TFLite dentro del proceso. No hay red.
    await NsfwDetector.initialize(threshold: 0.4);
    _ready = true;
  }

  /// Clasifica imágenes nuevas. Lo explícito se cifra; lo demás se copia a la carpeta pública.
  Future<ScanReport> scan() async {
    await ensureModel();
    final prefs = await os.prefs();
    final removeSource = prefs['removeSource'] == true;
    final hasDest = (prefs['dest'] as String?)?.isNotEmpty == true;

    final images = await os.channel.invokeListMethod<dynamic>('listImages') ?? const [];
    final seen = (await os.channel.invokeListMethod<String>('readSeen') ?? const []).toSet();

    var safe = 0;
    var vault = 0;
    var skipped = 0;

    for (final raw in images) {
      final item = Map<String, dynamic>.from(raw as Map);
      final uri = item['uri'] as String? ?? '';
      final name = item['name'] as String? ?? 'imagen';
      if (uri.isEmpty) continue;
      final signature = '$name:${item['size']}:${item['modified']}';
      if (seen.contains(signature)) continue;

      final bytes = await os.channel.invokeMethod<Uint8List>('readFile', {'uri': uri});
      if (bytes == null || bytes.isEmpty) {
        skipped += 1;
        continue;
      }

      final result = await NsfwDetector.instance.detectNSFWFromBytes(bytes);
      if (result?.isNsfw == true) {
        final packed = packPayload(name: name, mime: _mime(name), image: bytes);
        await os.channel.invokeMethod<String>('encryptStore', {'bytes': packed});
        vault += 1;
      } else {
        if (!hasDest) {
          skipped += 1;
          continue;
        }
        final wrote = await os.channel.invokeMethod<bool>('writePublic', {
              'name': name,
              'bytes': bytes,
            }) ??
            false;
        if (!wrote) {
          skipped += 1;
          continue;
        }
        safe += 1;
      }

      if (removeSource) {
        await os.channel.invokeMethod<bool>('deleteFile', {'uri': uri});
      }
      seen.add(signature);
      await os.channel.invokeMethod('addSeen', {'signature': signature});
    }

    return ScanReport(safe: safe, vault: vault, skipped: skipped);
  }

  /// Lee Descargas. Lo normal va a Pictures/Clasificadas. Lo NSFW, a la carpeta privada de la app.
  Future<ScanReport> clasificarDescargas({void Function(int done, int total)? onProgress}) async {
    await ensureModel();
    final allowed = await os.channel.invokeMethod<bool>('prepareSort') ?? false;
    if (!allowed) {
      await os.openAllFilesSettings();
      throw StateError('Concede acceso a todos los archivos y pulsa de nuevo');
    }

    final prefs = await os.prefs();
    final threshold = ((prefs['threshold'] as num?) ?? 40) / 100.0;
    final images = await os.channel.invokeListMethod<dynamic>('listImages') ?? const [];
    var safe = 0;
    var vault = 0;
    var skipped = 0;
    final total = images.length;

    for (var index = 0; index < images.length; index++) {
      onProgress?.call(index + 1, total);
      await Future<void>.delayed(Duration.zero);
      final item = Map<String, dynamic>.from(images[index] as Map);
      final uri = item['uri'] as String? ?? '';
      final name = item['name'] as String? ?? 'imagen';
      if (uri.isEmpty) {
        skipped += 1;
        continue;
      }

      final preview = await os.channel.invokeMethod<Uint8List>('previewJpeg', {'uri': uri});
      if (preview == null || preview.isEmpty) {
        skipped += 1;
        continue;
      }

      final result = await NsfwDetector.instance.detectNSFWFromBytes(preview);
      final privateFile = (result?.score ?? 0) >= threshold;
      final moved = await os.channel.invokeMethod<bool>('moveSorted', {
            'uri': uri,
            'name': name,
            'private': privateFile,
          }) ??
          false;
      if (!moved) {
        skipped += 1;
        continue;
      }
      if (privateFile) {
        vault += 1;
      } else {
        safe += 1;
      }
    }

    await os.channel.invokeMethod<int>('publishPublic');
    return ScanReport(safe: safe, vault: vault, skipped: skipped);
  }
}

class ScanReport {
  const ScanReport({required this.safe, required this.vault, required this.skipped});

  final int safe;
  final int vault;
  final int skipped;

  bool get empty => safe == 0 && vault == 0 && skipped == 0;
}

String _mime(String name) {
  final lower = name.toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.webp')) return 'image/webp';
  if (lower.endsWith('.gif')) return 'image/gif';
  return 'image/jpeg';
}

/// [4 bytes longitud][json utf-8][imagen]. El paquete completo lo cifra el Keystore.
Uint8List packPayload({required String name, required String mime, required Uint8List image}) {
  final header = utf8.encode(jsonEncode({'name': name, 'mime': mime}));
  final out = BytesBuilder(copy: false);
  final length = ByteData(4)..setUint32(0, header.length);
  out.add(length.buffer.asUint8List());
  out.add(header);
  out.add(image);
  return out.toBytes();
}

class UnpackedImage {
  const UnpackedImage({required this.name, required this.mime, required this.bytes});

  final String name;
  final String mime;
  final Uint8List bytes;
}

UnpackedImage unpackPayload(Uint8List packet) {
  final view = ByteData.sublistView(packet);
  final headerLength = view.getUint32(0);
  final header = utf8.decode(packet.sublist(4, 4 + headerLength));
  final meta = jsonDecode(header) as Map<String, dynamic>;
  return UnpackedImage(
    name: meta['name'] as String? ?? 'cifrada',
    mime: meta['mime'] as String? ?? 'image/jpeg',
    bytes: Uint8List.sublistView(packet, 4 + headerLength),
  );
}

/// Punto de entrada del servicio en primer plano. No abre UI.
@pragma('vm:entry-point')
Future<void> vaultScan() async {
  WidgetsFlutterBinding.ensureInitialized();
  final organizer = LindeOrganizer();
  while (true) {
    try {
      final prefs = await organizer.os.prefs();
      if (prefs['watch'] == true) {
        await organizer.scan();
      }
    } catch (_) {
      // El siguiente ciclo reintenta. No tumbar el servicio por un archivo ilegible.
    }
    await Future<void>.delayed(const Duration(minutes: 10));
  }
}
