import 'package:flutter/cupertino.dart';

import 'home_screen.dart';

/// Cáscara visual. La clasificación y el cifrado siguen en src/organizer.dart.
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LindeApp());
}

class LindeApp extends StatelessWidget {
  const LindeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return CupertinoApp(
      title: 'Linde',
      debugShowCheckedModeBanner: false,
      // CupertinoApp no cambia de tema solo. El builder lee el brillo del sistema.
      builder: (context, child) {
        final brightness = MediaQuery.platformBrightnessOf(context);
        final dark = brightness == Brightness.dark;
        return CupertinoTheme(
          data: CupertinoThemeData(
            brightness: brightness,
            primaryColor: dark ? const Color(0xFF0091FF) : CupertinoColors.systemBlue,
            scaffoldBackgroundColor: dark ? const Color(0xFF000000) : const Color(0xFFE7E7EE),
            barBackgroundColor: const Color(0x00000000),
            textTheme: CupertinoTextThemeData(
              textStyle: TextStyle(
                fontSize: 17,
                color: dark ? const Color(0xFFFFFFFF) : CupertinoColors.black,
              ),
            ),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const HomeScreen(),
    );
  }
}
