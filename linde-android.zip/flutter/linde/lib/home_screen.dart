import 'dart:io';

import 'package:cupertino_liquid_glass/cupertino_liquid_glass.dart';
import 'package:flutter/cupertino.dart';

import 'src/organizer.dart';

// Fondo claro. El cristal se lee sobre el gris, no sobre blanco puro.
const _tvBackground = Color(0xFFF5F5F7);
const _tvCard = Color(0xFFFFFFFF);
const _tvAccent = Color(0xFF0091FF);
const _tvText = Color(0xFF1C1C1E);
const _tvSecondary = Color(0x993C3C43);

const _tvCardTheme = LiquidGlassThemeData(
  tintColor: _tvCard,
  tintOpacity: 0.62,
  edgeLightColor: Color(0xCCFFFFFF),
);

/// Datos ya existentes. Esta pantalla solo los muestra.
const folders = <LindeFolder>[
  LindeFolder(
    name: 'Descargas',
    detail: 'Vigilada',
    symbol: CupertinoIcons.arrow_down_circle,
    images: [],
  ),
  LindeFolder(
    name: 'Biblioteca',
    detail: 'Públicas',
    symbol: CupertinoIcons.photo_on_rectangle,
    images: [],
  ),
  LindeFolder(
    name: 'Bóveda',
    detail: 'Privadas',
    symbol: CupertinoIcons.lock,
    images: [],
  ),
  LindeFolder(
    name: 'Registro',
    detail: 'Movimientos',
    symbol: CupertinoIcons.list_bullet,
    images: [],
  ),
];

class LindeFolder {
  const LindeFolder({
    required this.name,
    required this.detail,
    required this.symbol,
    required this.images,
  });

  final String name;
  final String detail;
  final IconData symbol;
  final List<String> images;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  var _tab = 0;
  var _busy = false;
  var _progress = '';
  var _publicCount = 0;
  var _privateCount = 0;
  var _albumEpoch = 0;

  @override
  void initState() {
    super.initState();
    _reloadAlbums();
  }

  Future<void> _reloadAlbums() async {
    final os = LindeOs();
    final publicAlbum = await os.album('public');
    final privateAlbum = await os.album('private');
    await os.channel.invokeMethod<int>('publishPublic');
    if (!mounted) return;
    setState(() {
      _publicCount = publicAlbum.length;
      _privateCount = privateAlbum.length;
      _albumEpoch += 1;
    });
  }

  Future<void> _clasificar() async {
    setState(() {
      _busy = true;
      _progress = 'Buscando fotos…';
    });
    try {
      final report = await LindeOrganizer().clasificarDescargas(
        onProgress: (done, total) {
          if (!mounted) return;
          setState(() => _progress = '$done de $total');
        },
      );
      if (!mounted) return;
      await showCupertinoDialog<void>(
        context: context,
        builder: (context) => CupertinoAlertDialog(
          title: const Text('Listo'),
          content: Text(
            report.empty
                ? 'No hay fotos nuevas. Lo ya revisado no se vuelve a leer.'
                : '${report.safe} normales\n${report.vault} explícitas\n${report.skipped} sin mover\nLa más alta fue ${(report.top * 100).round()}%\nLa más alta que se quedó fue ${(report.topKept * 100).round()}%',
          ),
          actions: [
            CupertinoDialogAction(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
          ],
        ),
      );
    } catch (error) {
      if (!mounted) return;
      await showCupertinoDialog<void>(
        context: context,
        builder: (context) => CupertinoAlertDialog(
          title: const Text('Permiso'),
          content: Text('$error'),
          actions: [
            CupertinoDialogAction(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
          ],
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _busy = false);
        _reloadAlbums();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = CupertinoTheme.brightnessOf(context) == Brightness.dark;
    return CupertinoPageScaffold(
      backgroundColor: dark ? _tvBackground : const Color(0xFFE7E7EE),
      child: Stack(
        children: [
          const _AmbientWash(),
          // Capa de vidrio esmerilado sobre el color de fondo.
          const Positioned.fill(
            child: CupertinoLiquidGlass(
              blurSigma: 32,
              tintOpacity: 0.22,
              borderRadius: BorderRadius.zero,
              effectIntensity: 0.72,
              child: SizedBox.expand(),
            ),
          ),
          Positioned.fill(
            child: SafeArea(
              bottom: false,
              child: IndexedStack(
                index: _tab,
                children: [
                  _FolderGrid(
                    busy: _busy,
                    progress: _progress,
                    publicCount: _publicCount,
                    privateCount: _privateCount,
                    onClassify: _clasificar,
                  ),
                  _AlbumPage(key: ValueKey('public-$_albumEpoch'), which: 'public', title: 'Biblioteca'),
                  _AlbumPage(key: ValueKey('private-$_albumEpoch'), which: 'private', title: 'Bóveda'),
                  _SettingsPage(),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: CupertinoLiquidGlassBottomBar(
              currentIndex: _tab,
              onTap: (index) => setState(() => _tab = index),
              activeColor: _tvAccent,
              items: const [
                LiquidGlassBottomBarItem(
                  icon: CupertinoIcons.square_grid_2x2,
                  activeIcon: CupertinoIcons.square_grid_2x2_fill,
                  label: 'Inicio',
                ),
                LiquidGlassBottomBarItem(
                  icon: CupertinoIcons.photo,
                  activeIcon: CupertinoIcons.photo_fill,
                  label: 'Biblioteca',
                ),
                LiquidGlassBottomBarItem(
                  icon: CupertinoIcons.lock,
                  activeIcon: CupertinoIcons.lock_fill,
                  label: 'Bóveda',
                ),
                LiquidGlassBottomBarItem(
                  icon: CupertinoIcons.gear,
                  activeIcon: CupertinoIcons.gear_alt_fill,
                  label: 'Ajustes',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FolderGrid extends StatelessWidget {
  const _FolderGrid({
    required this.busy,
    required this.progress,
    required this.publicCount,
    required this.privateCount,
    required this.onClassify,
  });

  final bool busy;
  final String progress;
  final int publicCount;
  final int privateCount;
  final VoidCallback onClassify;

  @override
  Widget build(BuildContext context) {
    final muted = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvSecondary
        : CupertinoColors.secondaryLabel.resolveFrom(context);
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 0),
          sliver: SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Linde', style: _title(context)),
                const SizedBox(height: 6),
                Text('Elige una carpeta', style: TextStyle(color: muted, fontSize: 15)),
                const SizedBox(height: 16),
                CupertinoButton.filled(
                  onPressed: busy ? null : onClassify,
                  child: Text(busy ? progress : 'Clasificar ahora'),
                ),
              ],
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 128),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 220,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 1.05,
            ),
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final folder = folders[index];
                return _FolderCard(
                  folder: folder,
                  count: index == 1 ? publicCount : index == 2 ? privateCount : folder.images.length,
                  onTap: () {
                    final which = index == 2 ? 'private' : 'public';
                    final title = index == 2 ? 'Bóveda' : 'Biblioteca';
                    if (index != 1 && index != 2) return;
                    Navigator.of(context).push(
                      CupertinoPageRoute<void>(
                        builder: (_) => _AlbumPage(which: which, title: title, showBack: true),
                      ),
                    );
                  },
                );
              },
              childCount: folders.length,
            ),
          ),
        ),
      ],
    );
  }
}

class _FolderCard extends StatelessWidget {
  const _FolderCard({required this.folder, required this.count, required this.onTap});

  final LindeFolder folder;
  final int count;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final label = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvText
        : CupertinoColors.label.resolveFrom(context);
    final muted = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvSecondary
        : CupertinoColors.secondaryLabel.resolveFrom(context);
    return CupertinoButton(
      padding: EdgeInsets.zero,
      minimumSize: Size.zero,
      onPressed: onTap,
      child: CupertinoLiquidGlass(
        theme: _tvCardTheme,
        borderRadius: BorderRadius.circular(28),
        glowRadius: 0,
        edgeLightColor: const Color(0x33FFFFFF),
        padding: const EdgeInsets.all(18),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(folder.symbol, size: 28, color: label),
              const Spacer(),
              Text(folder.name, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: label)),
              const SizedBox(height: 2),
              Text(
                '$count · ${folder.detail}',
                style: TextStyle(fontSize: 13, color: muted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AlbumPage extends StatefulWidget {
  const _AlbumPage({super.key, required this.which, required this.title, this.showBack = false});

  final String which;
  final String title;
  final bool showBack;

  @override
  State<_AlbumPage> createState() => _AlbumPageState();
}

class _AlbumPageState extends State<_AlbumPage> {
  var _paths = const <String>[];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final os = LindeOs();
    if (widget.which == 'public') {
      await os.channel.invokeMethod<int>('publishPublic');
    }
    final paths = await os.album(widget.which);
    if (!mounted) return;
    setState(() => _paths = paths);
  }

  @override
  Widget build(BuildContext context) {
    final dark = CupertinoTheme.brightnessOf(context) == Brightness.dark;
    final label = dark ? _tvText : CupertinoColors.label.resolveFrom(context);
    final body = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (widget.showBack)
          CupertinoButton(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Inicio'),
          )
        else
          const SizedBox(height: 28),
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 12),
          child: Text(widget.title, style: _title(context)),
        ),
        Expanded(
          child: _paths.isEmpty
              ? Center(child: Text('Todavía no hay fotos aquí', style: TextStyle(color: label)))
              : GridView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 128),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    mainAxisSpacing: 8,
                    crossAxisSpacing: 8,
                  ),
                  itemCount: _paths.length,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () async {
                        await Navigator.of(context).push<bool>(
                          CupertinoPageRoute<bool>(
                            builder: (_) => _PhotoPage(
                              paths: _paths,
                              initial: index,
                              privateAlbum: widget.which == 'private',
                            ),
                          ),
                        );
                        if (mounted) _load();
                      },
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: Image.file(
                          File(path),
                          fit: BoxFit.cover,
                          cacheWidth: 480,
                          errorBuilder: (_, _, _) => const ColoredBox(color: Color(0xFF1C1C1E)),
                        ),
                      ),
                    );
                  },
                ),
        ),
      ],
    );
    if (!widget.showBack) return body;
    return CupertinoPageScaffold(
      backgroundColor: dark ? _tvBackground : const Color(0xFFE7E7EE),
      child: SafeArea(child: body),
    );
  }
}

class _PhotoPage extends StatefulWidget {
  const _PhotoPage({required this.paths, required this.initial, required this.privateAlbum});

  final List<String> paths;
  final int initial;
  final bool privateAlbum;

  @override
  State<_PhotoPage> createState() => _PhotoPageState();
}

class _PhotoPageState extends State<_PhotoPage> {
  late final PageController _controller = PageController(initialPage: widget.initial);
  late List<String> _paths = List<String>.of(widget.paths);
  var _index = 0;
  var _busy = false;

  @override
  void initState() {
    super.initState();
    _index = widget.initial;
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _move() async {
    if (_busy || _paths.isEmpty) return;
    final path = _paths[_index];
    final name = path.split('/').last;
    setState(() => _busy = true);
    final ok = await LindeOs().channel.invokeMethod<bool>('moveSorted', {
          'uri': path,
          'name': name,
          'private': !widget.privateAlbum,
        }) ??
        false;
    if (!mounted) return;
    if (!ok) {
      setState(() => _busy = false);
      return;
    }
    _paths.removeAt(_index);
    if (_paths.isEmpty) {
      if (mounted) Navigator.of(context).pop();
      return;
    }
    final next = _index.clamp(0, _paths.length - 1);
    setState(() {
      _busy = false;
      _index = next;
    });
    _controller.jumpToPage(next);
  }

  @override
  Widget build(BuildContext context) {
    final label = widget.privateAlbum ? 'Devolver a Biblioteca' : 'Mover a la bóveda';
    return CupertinoPageScaffold(
      backgroundColor: const Color(0xFF000000),
      child: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                CupertinoButton(
                  onPressed: () => Navigator.of(context).pop(),
                  child: const Text('Cerrar'),
                ),
                  const Spacer(),
                  if (_paths.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(right: 16),
                      child: Text(
                        '${_index + 1} / ${_paths.length}',
                        style: const TextStyle(color: Color(0xFFFFFFFF)),
                      ),
                    ),
                ],
              ),
              Expanded(
                child: _paths.isEmpty
                    ? const SizedBox.shrink()
                    : PageView.builder(
                        controller: _controller,
                        itemCount: _paths.length,
                        onPageChanged: (value) => setState(() => _index = value),
                        itemBuilder: (_, index) => InteractiveViewer(
                          child: Image.file(File(_paths[index]), fit: BoxFit.contain),
                        ),
                      ),
              ),
              CupertinoButton(
                onPressed: _busy ? null : _move,
                child: Text(_busy ? 'Moviendo…' : label),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SettingsPage extends StatefulWidget {
  const _SettingsPage();

  @override
  State<_SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<_SettingsPage> {
  double _threshold = 0.4;
  var _soft = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final prefs = await LindeOs().prefs();
    final value = ((prefs['threshold'] as num?) ?? 40) / 100;
    if (!mounted) return;
    setState(() {
      _threshold = value.clamp(0.01, 0.9);
      _soft = prefs['treatSuggestive'] != false;
    });
  }

  Future<void> _save(double value) async {
    setState(() => _threshold = value);
    await LindeOs().setPrefs({'threshold': (value * 100).round()});
  }

  Future<void> _saveSoft(bool value) async {
    setState(() => _soft = value);
    await LindeOs().setPrefs({'treatSuggestive': value});
  }

  @override
  Widget build(BuildContext context) {
    final label = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvText
        : CupertinoColors.label.resolveFrom(context);
    final muted = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvSecondary
        : CupertinoColors.secondaryLabel.resolveFrom(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 28, 20, 128),
      children: [
        Text('Ajustes', style: _title(context)),
        const SizedBox(height: 8),
        Text('Más alto, más fotos se quedan en la biblioteca.', style: TextStyle(color: muted)),
        const SizedBox(height: 20),
        CupertinoLiquidGlass(
          borderRadius: BorderRadius.circular(28),
          edgeLightColor: const Color(0x80FFFFFF),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Umbral explícito', style: TextStyle(color: label, fontSize: 17, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              Text('${(_threshold * 100).round()}%', style: TextStyle(color: muted)),
              CupertinoSlider(
                value: _threshold,
                min: 0.01,
                max: 0.9,
                activeColor: _tvAccent,
                onChanged: _save,
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      'Ropa interior y dibujos subidos de tono',
                      style: TextStyle(color: label, fontSize: 15),
                    ),
                  ),
                  CupertinoSwitch(value: _soft, activeTrackColor: _tvAccent, onChanged: _saveSoft),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AmbientWash extends StatelessWidget {
  const _AmbientWash();

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFFFFFFF), Color(0xFFE5E5EA)],
        ),
      ),
    );
  }
}

TextStyle _title(BuildContext context) {
  return TextStyle(
    fontSize: 40,
    fontWeight: FontWeight.w600,
    letterSpacing: -0.8,
    color: CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvText
        : CupertinoColors.label.resolveFrom(context),
  );
}
