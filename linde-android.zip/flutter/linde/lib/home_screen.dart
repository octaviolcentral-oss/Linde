import 'package:cupertino_liquid_glass/cupertino_liquid_glass.dart';
import 'package:flutter/cupertino.dart';

import 'src/organizer.dart';

// Paleta tvOS 26, modo oscuro.
const _tvBackground = Color(0xFF000000);
const _tvCard = Color(0xFF1C1C1E);
const _tvAccent = Color(0xFF0091FF);
const _tvText = Color(0xFFFFFFFF);
const _tvSecondary = Color(0x99EBEBF5); // #EBEBF5 al 60%

const _tvCardTheme = LiquidGlassThemeData(
  tintColor: _tvCard,
  tintOpacity: 0.94,
  edgeLightColor: Color(0x38FFFFFF),
);

/// Datos ya existentes. Esta pantalla solo los muestra.
const folders = <LindeFolder>[
  LindeFolder(
    name: 'Descargas',
    detail: 'Vigilada',
    symbol: CupertinoIcons.arrow_down_circle,
    images: ['captura-12.jpg', 'recibo.png', 'nota.webp'],
  ),
  LindeFolder(
    name: 'Biblioteca',
    detail: 'Públicas',
    symbol: CupertinoIcons.photo_on_rectangle,
    images: ['playa.jpg', 'coche.png', 'prueba-linde.jpg'],
  ),
  LindeFolder(
    name: 'Bóveda',
    detail: 'Cifradas',
    symbol: CupertinoIcons.lock,
    images: ['privada-01', 'privada-02'],
  ),
  LindeFolder(
    name: 'Registro',
    detail: 'Movimientos',
    symbol: CupertinoIcons.list_bullet,
    images: [],
  ),
];

class LindeFolder {
  const LindeFolder({
    required this.name,
    required this.detail,
    required this.symbol,
    required this.images,
  });

  final String name;
  final String detail;
  final IconData symbol;
  final List<String> images;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  var _tab = 0;
  var _busy = false;

  Future<void> _clasificar() async {
    setState(() => _busy = true);
    try {
      final report = await LindeOrganizer().clasificarDescargas();
      if (!mounted) return;
      await showCupertinoDialog<void>(
        context: context,
        builder: (context) => CupertinoAlertDialog(
          title: const Text('Listo'),
          content: Text(
            if (report.empty) {
              'No encontré fotos en la cámara, en Imágenes ni en Descargas.'
            } else {
              '${report.safe} a Pictures/Clasificadas\n${report.vault} a la carpeta privada\n${report.skipped} sin mover'
            },
          ),
          actions: [
            CupertinoDialogAction(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
          ],
        ),
      );
    } catch (error) {
      if (!mounted) return;
      await showCupertinoDialog<void>(
        context: context,
        builder: (context) => CupertinoAlertDialog(
          title: const Text('Permiso'),
          content: Text('$error'),
          actions: [
            CupertinoDialogAction(onPressed: () => Navigator.pop(context), child: const Text('Cerrar')),
          ],
        ),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dark = CupertinoTheme.brightnessOf(context) == Brightness.dark;
    return CupertinoPageScaffold(
      backgroundColor: dark ? _tvBackground : const Color(0xFFE7E7EE),
      child: Stack(
        children: [
          const _AmbientWash(),
          // Capa de vidrio esmerilado sobre el color de fondo.
          const Positioned.fill(
            child: CupertinoLiquidGlass(
              blurSigma: 32,
              tintOpacity: 0.22,
              borderRadius: BorderRadius.zero,
              effectIntensity: 0.72,
              child: SizedBox.expand(),
            ),
          ),
          Positioned.fill(
            child: SafeArea(
              bottom: false,
              child: IndexedStack(
                index: _tab,
                children: [
                  _FolderGrid(busy: _busy, onClassify: _clasificar),
                  _LibraryPage(),
                  _VaultPage(),
                  _SettingsPage(),
                ],
              ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: CupertinoLiquidGlassBottomBar(
              currentIndex: _tab,
              onTap: (index) => setState(() => _tab = index),
              activeColor: _tvAccent,
              items: const [
                LiquidGlassBottomBarItem(
                  icon: CupertinoIcons.square_grid_2x2,
                  activeIcon: CupertinoIcons.square_grid_2x2_fill,
                  label: 'Inicio',
                ),
                LiquidGlassBottomBarItem(
                  icon: CupertinoIcons.photo,
                  activeIcon: CupertinoIcons.photo_fill,
                  label: 'Biblioteca',
                ),
                LiquidGlassBottomBarItem(
                  icon: CupertinoIcons.lock,
                  activeIcon: CupertinoIcons.lock_fill,
                  label: 'Bóveda',
                ),
                LiquidGlassBottomBarItem(
                  icon: CupertinoIcons.gear,
                  activeIcon: CupertinoIcons.gear_alt_fill,
                  label: 'Ajustes',
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FolderGrid extends StatelessWidget {
  const _FolderGrid({required this.busy, required this.onClassify});

  final bool busy;
  final VoidCallback onClassify;

  @override
  Widget build(BuildContext context) {
    final muted = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvSecondary
        : CupertinoColors.secondaryLabel.resolveFrom(context);
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(24, 28, 24, 0),
          sliver: SliverToBoxAdapter(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Linde', style: _title(context)),
                const SizedBox(height: 6),
                Text('Elige una carpeta', style: TextStyle(color: muted, fontSize: 15)),
                const SizedBox(height: 16),
                CupertinoButton.filled(
                  onPressed: busy ? null : onClassify,
                  child: Text(busy ? 'Clasificando…' : 'Clasificar ahora'),
                ),
              ],
            ),
          ),
        ),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 22, 20, 128),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
              maxCrossAxisExtent: 220,
              mainAxisSpacing: 16,
              crossAxisSpacing: 16,
              childAspectRatio: 1.05,
            ),
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final folder = folders[index];
                return _FolderCard(
                  folder: folder,
                  onTap: () {
                    Navigator.of(context).push(
                      CupertinoPageRoute<void>(
                        builder: (_) => FolderImagesScreen(folder: folder),
                      ),
                    );
                  },
                );
              },
              childCount: folders.length,
            ),
          ),
        ),
      ],
    );
  }
}

class _FolderCard extends StatelessWidget {
  const _FolderCard({required this.folder, required this.onTap});

  final LindeFolder folder;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final label = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvText
        : CupertinoColors.label.resolveFrom(context);
    final muted = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvSecondary
        : CupertinoColors.secondaryLabel.resolveFrom(context);
    return CupertinoButton(
      padding: EdgeInsets.zero,
      minimumSize: Size.zero,
      onPressed: onTap,
      child: CupertinoLiquidGlass(
        theme: _tvCardTheme,
        borderRadius: BorderRadius.circular(28),
        glowColor: _tvAccent.withValues(alpha: 0.45),
        glowRadius: 22,
        edgeLightColor: const Color(0x99FFFFFF),
        padding: const EdgeInsets.all(18),
        child: SizedBox(
          width: double.infinity,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(folder.symbol, size: 28, color: label),
              const Spacer(),
              Text(folder.name, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: label)),
              const SizedBox(height: 2),
              Text(
                '${folder.images.length} · ${folder.detail}',
                style: TextStyle(fontSize: 13, color: muted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class FolderImagesScreen extends StatelessWidget {
  const FolderImagesScreen({super.key, required this.folder});

  final LindeFolder folder;

  @override
  Widget build(BuildContext context) {
    final dark = CupertinoTheme.brightnessOf(context) == Brightness.dark;
    return CupertinoPageScaffold(
      backgroundColor: dark ? _tvBackground : const Color(0xFFE7E7EE),
      child: Stack(
        children: [
          const _AmbientWash(),
          const Positioned.fill(
            child: CupertinoLiquidGlass(
              blurSigma: 28,
              tintOpacity: 0.2,
              borderRadius: BorderRadius.zero,
              effectIntensity: 0.7,
              child: SizedBox.expand(),
            ),
          ),
          SafeArea(child: _ImageList(folder: folder, showBack: true)),
        ],
      ),
    );
  }
}

class _ImageList extends StatelessWidget {
  const _ImageList({required this.folder, required this.showBack});

  final LindeFolder folder;
  final bool showBack;

  @override
  Widget build(BuildContext context) {
    final label = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvText
        : CupertinoColors.label.resolveFrom(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (showBack)
          CupertinoButton(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Inicio'),
          )
        else
          const SizedBox(height: 28),
        Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 12),
          child: Text(folder.name, style: _title(context)),
        ),
        Expanded(
          child: folder.images.isEmpty
              ? Center(child: Text('Vacía', style: TextStyle(color: label)))
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 128),
                  itemCount: folder.images.length,
                  separatorBuilder: (_, _) => const SizedBox(height: 10),
                  itemBuilder: (context, index) {
                    return CupertinoLiquidGlass(
                      borderRadius: BorderRadius.circular(22),
                      edgeLightColor: const Color(0x66FFFFFF),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      child: Row(
                        children: [
                          Icon(CupertinoIcons.photo, color: label, size: 22),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              folder.images[index],
                              style: TextStyle(color: label, fontSize: 16),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}

class _LibraryPage extends StatelessWidget {
  const _LibraryPage();

  @override
  Widget build(BuildContext context) {
    return _ImageList(folder: folders[1], showBack: false);
  }
}

class _VaultPage extends StatelessWidget {
  const _VaultPage();

  @override
  Widget build(BuildContext context) {
    return _ImageList(folder: folders[2], showBack: false);
  }
}

class _SettingsPage extends StatelessWidget {
  const _SettingsPage();

  @override
  Widget build(BuildContext context) {
    final label = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvText
        : CupertinoColors.label.resolveFrom(context);
    final muted = CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvSecondary
        : CupertinoColors.secondaryLabel.resolveFrom(context);
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 28, 20, 128),
      children: [
        Text('Ajustes', style: _title(context)),
        const SizedBox(height: 8),
        Text('El vidrio sigue el modo claro u oscuro del sistema.', style: TextStyle(color: muted)),
        const SizedBox(height: 20),
        CupertinoLiquidGlass(
          borderRadius: BorderRadius.circular(28),
          edgeLightColor: const Color(0x80FFFFFF),
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Umbral explícito', style: TextStyle(color: label, fontSize: 17, fontWeight: FontWeight.w600)),
              const SizedBox(height: 6),
              Text('40%', style: TextStyle(color: muted)),
            ],
          ),
        ),
      ],
    );
  }
}

class _AmbientWash extends StatelessWidget {
  const _AmbientWash();

  @override
  Widget build(BuildContext context) {
    return const IgnorePointer(
      child: Stack(
        children: [
          Positioned(top: -80, left: -40, child: _Orb(color: Color(0xFF5B8CFF), size: 280)),
          Positioned(top: 180, right: -60, child: _Orb(color: Color(0xFFE07A5F), size: 240)),
          Positioned(bottom: 40, left: 40, child: _Orb(color: Color(0xFF7DDE92), size: 200)),
        ],
      ),
    );
  }
}

class _Orb extends StatelessWidget {
  const _Orb({required this.color, required this.size});

  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color.withValues(alpha: 0.55)),
    );
  }
}

TextStyle _title(BuildContext context) {
  return TextStyle(
    fontSize: 40,
    fontWeight: FontWeight.w600,
    letterSpacing: -0.8,
    color: CupertinoTheme.brightnessOf(context) == Brightness.dark
        ? _tvText
        : CupertinoColors.label.resolveFrom(context),
  );
}
