# Linde (Android)

Organizador local de imágenes. Lo neutro se copia a una carpeta pública elegida por ti. Lo explícito se cifra con AES-256-GCM y se guarda en el almacenamiento interno de la app. El modelo `nsfw_detect` corre en el teléfono (TensorFlow Lite). No hay red en el build de release.

## Probar en un dispositivo

Hace falta Flutter 3.22+ (Dart 3.4+) y un teléfono o emulador con Android 8+ (API 26).

```bash
flutter pub get
flutter run
```

Si Gradle se queja de que falta el wrapper (`gradlew`), genera los archivos de plataforma sin pisar `lib/`:

```bash
flutter create --org com.linde --project-name linde --platforms android .
```

Vuelve a comprobar que `android/app/src/main/kotlin/com/linde/vault/` y el `AndroidManifest.xml` siguen siendo los de este proyecto.

La primera vez, elige la carpeta de entrada (Descargas) y la carpeta pública. Pulsa **Clasificar ahora**. Con **Seguir en segundo plano** activo, al salir de la app arranca un servicio en primer plano que repite el pase cada 10 minutos. Al volver a abrirla también clasifica sola.

## Permisos (AndroidManifest)

| Permiso | Para qué |
| --- | --- |
| Selector SAF (`ACTION_OPEN_DOCUMENT_TREE`) | Vía principal. El usuario elige carpetas y el permiso del árbol se persiste. Es la opción viable en Play. |
| `MANAGE_EXTERNAL_STORAGE` | Opcional. Ruta directa de Descargas en Android 11+. Si se niega, SAF basta. |
| `READ_MEDIA_IMAGES` | Lectura de imágenes en Android 13+. |
| `READ_EXTERNAL_STORAGE` (max 32) | Lo mismo hasta Android 12. |
| `WRITE_EXTERNAL_STORAGE` (max 29) | Escritura heredada en Android 9 y anteriores. |
| `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC` | Aviso permanente mientras clasifica fuera de pantalla. |
| Sin `INTERNET` en release | El modelo y el cifrado no salen del dispositivo. El manifiesto de debug sí lo tiene, para el depurador de Flutter. |

## Cifrado

`VaultCipher` crea una clave AES-256 en Android Keystore (`linde_vault_aes`), modo GCM, sin padding. La clave no se exporta. Cada archivo de la bóveda es `IV (12) + texto cifrado + tag` dentro de `files/vault/`, no en una carpeta oculta de Descargas.
