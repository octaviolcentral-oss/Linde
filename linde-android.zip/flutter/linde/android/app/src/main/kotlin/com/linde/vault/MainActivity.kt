package com.linde.vault

import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine

class MainActivity : FlutterActivity() {
    private val bridge by lazy { LindeBridge(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        // El launcher tiene que existir antes de que la actividad arranque.
        bridge.registerTreeLauncher(this)
        super.onCreate(savedInstanceState)
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        bridge.attach(flutterEngine.dartExecutor.binaryMessenger)
    }
}
