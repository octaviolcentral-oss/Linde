package com.linde.vault

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.os.Environment
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import android.provider.DocumentsContract
import android.provider.Settings
import androidx.activity.result.ActivityResultLauncher
import androidx.documentfile.provider.DocumentFile
import io.flutter.plugin.common.BinaryMessenger
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import java.io.File
import java.util.UUID

/**
 * IO de carpetas y bóveda. Lo registra tanto la Activity como el servicio en segundo plano:
 * el isolate de fondo no ve los canales de la UI.
 */
class LindeBridge(private val context: Context) {
    private var treeLauncher: ActivityResultLauncher<Uri?>? = null
    private var pendingPick: MethodChannel.Result? = null
    private var pickingDestination = false

    fun registerTreeLauncher(activity: androidx.activity.ComponentActivity) {
        treeLauncher = activity.registerForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.OpenDocumentTree(),
        ) { uri ->
            val result = pendingPick
            pendingPick = null
            if (result == null) return@registerForActivityResult
            if (uri == null) {
                result.success(null)
                return@registerForActivityResult
            }
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            context.contentResolver.takePersistableUriPermission(uri, flags)
            val label = DocumentFile.fromTreeUri(context, uri)?.name ?: "carpeta"
            val prefs = prefs()
            if (pickingDestination) {
                prefs.edit().putString("dest", uri.toString()).putString("destLabel", label).apply()
            } else {
                prefs.edit().putString("source", uri.toString()).putString("sourceLabel", label).apply()
            }
            result.success(label)
        }
    }

    fun attach(messenger: BinaryMessenger) {
        MethodChannel(messenger, CHANNEL).setMethodCallHandler(::onCall)
    }

    private fun onCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "getPrefs" -> result.success(readPrefs())
                "setPrefs" -> {
                    writePrefs(call.arguments as? Map<*, *>)
                    result.success(null)
                }
                "pickTree" -> pickTree(call.argument<Boolean>("destination") == true, result)
                "useDownloads" -> {
                    prefs().edit()
                        .putString("source", DOWNLOADS)
                        .putString("sourceLabel", "Descargas")
                        .apply()
                    result.success(null)
                }
                "prepareSort" -> result.success(prepareSort())
                "hasAllFiles" -> result.success(Environment.isExternalStorageManager())
                "openAllFilesSettings" -> {
                    openAllFilesSettings()
                    result.success(null)
                }
                "listImages" -> result.success(listImages())
                "listVideos" -> result.success(listVideos())
                "videoFrames" -> {
                    val uri = call.argument<String>("uri") ?: error("uri")
                    result.success(videoFrames(uri))
                }
                "moveVideo" -> {
                    val uri = call.argument<String>("uri") ?: error("uri")
                    val name = call.argument<String>("name") ?: error("name")
                    result.success(moveVideo(uri, name))
                }
                "readFile" -> {
                    val uri = call.argument<String>("uri") ?: error("uri")
                    result.success(readBytes(uri))
                }
                "previewJpeg" -> {
                    val uri = call.argument<String>("uri") ?: error("uri")
                    result.success(previewJpeg(uri))
                }
                "moveSorted" -> {
                    val uri = call.argument<String>("uri") ?: error("uri")
                    val name = call.argument<String>("name") ?: error("name")
                    val privateFile = call.argument<Boolean>("private") == true
                    result.success(moveSorted(uri, name, privateFile))
                }
                "listAlbum" -> {
                    val which = call.argument<String>("which") ?: "public"
                    result.success(listAlbum(which))
                }
                "publishPublic" -> {
                    result.success(publishPublic())
                }
                "writePublic" -> {
                    val name = call.argument<String>("name") ?: error("name")
                    val bytes = call.argument<ByteArray>("bytes") ?: error("bytes")
                    result.success(writePublic(name, bytes))
                }
                "writePrivate" -> {
                    val name = call.argument<String>("name") ?: error("name")
                    val bytes = call.argument<ByteArray>("bytes") ?: error("bytes")
                    result.success(writePrivate(name, bytes))
                }
                "deleteFile" -> {
                    val uri = call.argument<String>("uri") ?: error("uri")
                    result.success(deleteUri(uri))
                }
                "encryptStore" -> {
                    val bytes = call.argument<ByteArray>("bytes") ?: error("bytes")
                    result.success(encryptStore(bytes))
                }
                "listVault" -> result.success(listVault())
                "decryptVault" -> {
                    val id = call.argument<String>("id") ?: error("id")
                    result.success(decryptVault(id))
                }
                "deleteVault" -> {
                    val id = call.argument<String>("id") ?: error("id")
                    result.success(deleteVault(id))
                }
                "readSeen" -> result.success(readSeen())
                "addSeen" -> {
                    val signature = call.argument<String>("signature") ?: error("signature")
                    addSeen(signature)
                    result.success(null)
                }
                "startWatcher" -> {
                    WatchService.start(context)
                    result.success(null)
                }
                "stopWatcher" -> {
                    WatchService.stop(context)
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        } catch (error: Exception) {
            result.error("linde", error.message, null)
        }
    }

    private fun pickTree(destination: Boolean, result: MethodChannel.Result) {
        val launcher = treeLauncher
        if (launcher == null) {
            result.error("linde", "El selector de carpetas solo está en la actividad", null)
            return
        }
        if (pendingPick != null) {
            result.error("linde", "Ya hay un selector abierto", null)
            return
        }
        pickingDestination = destination
        pendingPick = result
        val initial = if (destination) null else downloadsTreeUri()
        launcher.launch(initial)
    }

    private fun downloadsTreeUri(): Uri {
        return DocumentsContract.buildTreeDocumentUri(
            "com.android.externalstorage.documents",
            "primary:${Environment.DIRECTORY_DOWNLOADS}",
        )
    }

    private fun prefs() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun readPrefs(): Map<String, Any?> {
        val stored = prefs()
        return mapOf(
            "source" to stored.getString("source", ""),
            "dest" to stored.getString("dest", ""),
            "sourceLabel" to stored.getString("sourceLabel", ""),
            "destLabel" to stored.getString("destLabel", ""),
            "threshold" to stored.getInt("threshold", 40),
            "treatSuggestive" to stored.getBoolean("treatSuggestive", true),
            "reviewLibrary" to stored.getBoolean("reviewLibrary", false),
            "removeSource" to stored.getBoolean("removeSource", false),
            "watch" to stored.getBoolean("watch", true),
            "allFiles" to Environment.isExternalStorageManager(),
        )
    }

    private fun writePrefs(values: Map<*, *>?) {
        if (values == null) return
        val editor = prefs().edit()
        values.forEach { (key, value) ->
            when (key) {
                "threshold" -> editor.putInt("threshold", (value as Number).toInt())
                "treatSuggestive" -> editor.putBoolean("treatSuggestive", value == true)
                "reviewLibrary" -> editor.putBoolean("reviewLibrary", value == true)
                "removeSource" -> editor.putBoolean("removeSource", value == true)
                "watch" -> editor.putBoolean("watch", value == true)
            }
        }
        editor.apply()
    }

    private fun publicDir(): File = File(
        Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
        "Biblioteca",
    )

    private fun privateDir(): File {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            "Linde/privada",
        )
        dir.mkdirs()
        val hidden = File(dir, ".nomedia")
        if (!hidden.exists()) hidden.createNewFile()
        return dir
    }

    private fun prepareSort(): Boolean {
        val dest = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
            "Biblioteca",
        )
        dest.mkdirs()
        adoptOldLibrary(dest)
        privateDir()
        prefs().edit()
            .putString("source", DOWNLOADS)
            .putString("sourceLabel", "Descargas")
            .putString("dest", dest.absolutePath)
            .putString("destLabel", "Biblioteca")
            .apply()
        return Environment.isExternalStorageManager()
    }

    private fun adoptOldLibrary(dest: File) {
        val old = File(dest.parentFile, "Clasificadas")
        if (!old.isDirectory || old.absolutePath == dest.absolutePath) return
        dest.mkdirs()
        old.listFiles()?.forEach { file ->
            if (!file.isFile) return@forEach
            var target = File(dest, file.name)
            if (target.exists()) target = File(dest, "${file.lastModified()}_${file.name}")
            if (!file.renameTo(target)) {
                file.copyTo(target, overwrite = true)
                file.delete()
            }
        }
        if (old.listFiles().isNullOrEmpty()) old.delete()
    }

    private fun writePrivate(name: String, bytes: ByteArray): Boolean {
        val dir = privateDir()
        File(dir, name).writeBytes(bytes)
        return true
    }

    private fun listImages(): List<Map<String, Any>> {
        val source = prefs().getString("source", null) ?: return emptyList()
        if (source == DOWNLOADS) {
            if (!Environment.isExternalStorageManager()) return emptyList()
            val storage = Environment.getExternalStorageDirectory()
            val dest = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                "Biblioteca",
            )
            val found = mutableListOf<Map<String, Any>>()
            val seen = mutableSetOf<String>()
            for (dir in listOf(File(storage, "DCIM"), File(storage, "Pictures"), File(storage, "Download"))) {
                collectImages(dir, dest, found, seen, 0)
            }
            return found
        }
        val tree = DocumentFile.fromTreeUri(context, Uri.parse(source)) ?: return emptyList()
        return tree.listFiles().mapNotNull { doc ->
            val name = doc.name ?: return@mapNotNull null
            val type = doc.type.orEmpty()
            if (!doc.isFile || (!type.startsWith("image/") && !isImageName(name))) return@mapNotNull null
            mapOf(
                "uri" to doc.uri.toString(),
                "name" to name,
                "size" to doc.length(),
                "modified" to doc.lastModified(),
            )
        }
    }

    private fun collectImages(
        dir: File,
        dest: File,
        out: MutableList<Map<String, Any>>,
        seen: MutableSet<String>,
        depth: Int,
    ) {
        if (!dir.isDirectory || depth > 4) return
        if (dir.absolutePath == dest.absolutePath) return
        dir.listFiles()?.forEach { file ->
            if (file.isDirectory) {
                collectImages(file, dest, out, seen, depth + 1)
            } else if (isImageName(file.name) && seen.add(file.absolutePath)) {
                out.add(
                    mapOf(
                        "uri" to file.absolutePath,
                        "name" to file.name,
                        "size" to file.length(),
                        "modified" to file.lastModified(),
                        "sorted" to (file.parentFile?.absolutePath == dest.absolutePath),
                    ),
                )
            }
        }
    }

    private fun readBytes(uri: String): ByteArray {
        if (uri.startsWith("content:")) {
            return context.contentResolver.openInputStream(Uri.parse(uri))?.use { it.readBytes() }
                ?: error("No se pudo leer")
        }
        return File(uri).readBytes()
    }

    private fun previewJpeg(path: String): ByteArray? {
        if (path.startsWith("content:")) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / sample > 448 || bounds.outHeight / sample > 448) sample *= 2
        val bitmap = BitmapFactory.decodeFile(
            path,
            BitmapFactory.Options().apply { inSampleSize = sample },
        ) ?: return null
        return ByteArrayOutputStream().use { stream ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
            bitmap.recycle()
            stream.toByteArray()
        }
    }

    private fun moveSorted(path: String, name: String, privateFile: Boolean): Boolean {
        if (path.startsWith("content:")) return false
        val source = File(path)
        if (!source.isFile) return false
        val dir = if (privateFile) privateDir() else publicDir()
        if (!dir.mkdirs() && !dir.isDirectory) return false
        var target = File(dir, name)
        if (target.exists()) target = File(dir, "${source.lastModified()}_$name")
        source.copyTo(target, overwrite = true)
        if (!source.delete()) return false
        forgetFromGallery(source)
        if (!privateFile) {
            MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), null, null)
        }
        return true
    }

    private fun listAlbum(which: String): List<String> {
        val dir = when (which) {
            "private" -> privateDir()
            "videos" -> videoDir()
            else -> publicDir()
        }
        val video = which == "videos"
        return dir.listFiles().orEmpty()
            .filter { it.isFile && if (video) isVideoName(it.name) else isImageName(it.name) }
            .sortedByDescending { it.lastModified() }
            .map { it.absolutePath }
    }

    private fun publishPublic(): Int {
        val paths = listAlbum("public")
        if (paths.isNotEmpty()) {
            MediaScannerConnection.scanFile(context, paths.toTypedArray(), null, null)
        }
        return paths.size
    }

    private fun forgetFromGallery(source: File) {
        forgetMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, source)
        forgetMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, source)
    }

    private fun forgetMedia(collection: Uri, source: File) {
        context.contentResolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.DATA}=?",
            arrayOf(source.absolutePath),
            null,
        )?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idColumn)
                context.contentResolver.delete(
                    android.content.ContentUris.withAppendedId(collection, id),
                    null,
                    null,
                )
            }
        }
    }

    private fun videoDir(): File {
        val dir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
            "Linde/videos",
        )
        dir.mkdirs()
        val hidden = File(dir, ".nomedia")
        if (!hidden.exists()) hidden.createNewFile()
        return dir
    }

    private fun listVideos(): List<Map<String, Any>> {
        if (!Environment.isExternalStorageManager()) return emptyList()
        val storage = Environment.getExternalStorageDirectory()
        val skip = setOf(
            publicDir().absolutePath,
            privateDir().absolutePath,
            videoDir().absolutePath,
        )
        val found = mutableListOf<Map<String, Any>>()
        val seen = mutableSetOf<String>()
        for (dir in listOf(
            File(storage, "DCIM"),
            File(storage, "Movies"),
            File(storage, "Download"),
            File(storage, "Pictures"),
        )) {
            collectVideos(dir, skip, found, seen, 0)
        }
        return found
    }

    private fun collectVideos(
        dir: File,
        skip: Set<String>,
        out: MutableList<Map<String, Any>>,
        seen: MutableSet<String>,
        depth: Int,
    ) {
        if (!dir.isDirectory || depth > 4 || dir.absolutePath in skip) return
        dir.listFiles()?.forEach { file ->
            if (file.isDirectory) {
                collectVideos(file, skip, out, seen, depth + 1)
            } else if (isVideoName(file.name) && seen.add(file.absolutePath)) {
                out.add(
                    mapOf(
                        "uri" to file.absolutePath,
                        "name" to file.name,
                        "size" to file.length(),
                        "modified" to file.lastModified(),
                    ),
                )
            }
        }
    }

    private fun videoFrames(path: String): List<ByteArray> {
        val file = File(path)
        if (!file.isFile) return emptyList()
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(path)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val marks = if (durationMs <= 0L) {
                listOf(0L)
            } else {
                listOf(0L, durationMs / 4, durationMs / 2, durationMs * 3 / 4)
            }
            marks.mapNotNull { mark ->
                val frame = retriever.getFrameAtTime(mark * 1000, MediaMetadataRetriever.OPTION_CLOSEST) ?: return@mapNotNull null
                val scaled = if (frame.width > 448) {
                    val height = (frame.height * 448f / frame.width).toInt().coerceAtLeast(1)
                    Bitmap.createScaledBitmap(frame, 448, height, true).also { if (it != frame) frame.recycle() }
                } else {
                    frame
                }
                ByteArrayOutputStream().use { stream ->
                    scaled.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                    scaled.recycle()
                    stream.toByteArray()
                }
            }
        } catch (_: Exception) {
            emptyList()
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun moveVideo(path: String, name: String): Boolean {
        val source = File(path)
        if (!source.isFile) return false
        val dir = videoDir()
        var target = File(dir, name)
        if (target.exists()) target = File(dir, "${source.lastModified()}_$name")
        val moved = if (source.renameTo(target)) {
            true
        } else {
            source.copyTo(target, overwrite = true)
            source.delete()
        }
        if (!moved || !target.isFile) return false
        forgetFromGallery(source)
        return true
    }

    private fun isVideoName(name: String): Boolean {
        val lower = name.lowercase()
        return lower.endsWith(".mp4") ||
            lower.endsWith(".mov") ||
            lower.endsWith(".m4v") ||
            lower.endsWith(".webm") ||
            lower.endsWith(".mkv") ||
            lower.endsWith(".3gp") ||
            lower.endsWith(".avi")
    }

    private fun writePublic(name: String, bytes: ByteArray): Boolean {
        val dest = prefs().getString("dest", null)?.takeIf { it.isNotEmpty() } ?: return false
        if (dest.startsWith("content:")) {
            val tree = DocumentFile.fromTreeUri(context, Uri.parse(dest)) ?: return false
            tree.findFile(name)?.delete()
            val created = tree.createFile(mimeFor(name), name) ?: return false
            context.contentResolver.openOutputStream(created.uri)?.use { stream ->
                stream.write(bytes)
            } ?: return false
            return true
        }
        if (!Environment.isExternalStorageManager()) return false
        File(dest, name).writeBytes(bytes)
        return true
    }

    private fun deleteUri(uri: String): Boolean {
        if (uri.startsWith("content:")) {
            return DocumentsContract.deleteDocument(context.contentResolver, Uri.parse(uri))
        }
        return File(uri).delete()
    }

    private fun vaultDir(): File = File(context.filesDir, "vault").apply { mkdirs() }

    private fun encryptStore(bytes: ByteArray): String {
        val id = UUID.randomUUID().toString()
        File(vaultDir(), "$id.bin").writeBytes(VaultCipher.encrypt(bytes))
        return id
    }

    private fun listVault(): List<Map<String, Any>> {
        return vaultDir().listFiles { file -> file.extension == "bin" }.orEmpty()
            .sortedByDescending { it.lastModified() }
            .map { file ->
                mapOf(
                    "id" to file.nameWithoutExtension,
                    "addedAt" to file.lastModified(),
                    "bytes" to file.length(),
                )
            }
    }

    private fun decryptVault(id: String): ByteArray {
        val file = File(vaultDir(), "$id.bin")
        require(file.exists()) { "No está en la bóveda" }
        return VaultCipher.decrypt(file.readBytes())
    }

    private fun deleteVault(id: String): Boolean = File(vaultDir(), "$id.bin").delete()

    private fun seenFile(): File = File(context.filesDir, "seen.json")

    private fun readSeen(): List<String> {
        if (!seenFile().exists()) return emptyList()
        val array = JSONArray(seenFile().readText())
        return List(array.length()) { index -> array.getString(index) }
    }

    private fun addSeen(signature: String) {
        val current = readSeen().toMutableList()
        current.add(signature)
        val trimmed = if (current.size > 8000) current.takeLast(8000) else current
        seenFile().writeText(JSONArray(trimmed).toString())
    }

    private fun openAllFilesSettings() {
        val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
            data = Uri.parse("package:${context.packageName}")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        }
    }

    private fun isImageName(name: String): Boolean {
        val lower = name.lowercase()
        return lower.endsWith(".jpg") ||
            lower.endsWith(".jpeg") ||
            lower.endsWith(".png") ||
            lower.endsWith(".webp") ||
            lower.endsWith(".gif") ||
            lower.endsWith(".bmp") ||
            lower.endsWith(".heic") ||
            lower.endsWith(".heif")
    }

    private fun mimeFor(name: String): String {
        val lower = name.lowercase()
        return when {
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".webp") -> "image/webp"
            lower.endsWith(".gif") -> "image/gif"
            else -> "image/jpeg"
        }
    }

    companion object {
        const val CHANNEL = "com.linde/os"
        const val PREFS = "linde_prefs"
        const val DOWNLOADS = "downloads"
    }
}
