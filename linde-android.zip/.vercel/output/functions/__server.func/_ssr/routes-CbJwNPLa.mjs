import { o as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as FolderOutput, c as EyeOff, i as ImagePlus, l as Download, n as Trash2, o as FolderInput, r as Shield, s as Eye } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CbJwNPLa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var loading = null;
/** MobileNetV2 de nsfwjs, pesos incluidos en el paquete. No hay red. */
function loadLocalModel() {
	if (typeof window === "undefined") return Promise.reject(/* @__PURE__ */ new Error("El modelo solo corre en el navegador"));
	if (!loading) loading = (async () => {
		const tf = await import("../_libs/@tensorflow/tfjs.mjs").then((n) => n.t);
		await tf.ready();
		try {
			await tf.setBackend("webgl");
			await tf.ready();
		} catch {
			await tf.setBackend("cpu");
			await tf.ready();
		}
		const core = await import("../_libs/nsfwjs.mjs").then((n) => n.n);
		const mobilenet = await import("../_libs/nsfwjs.mjs").then((n) => n.t);
		return core.load("MobileNetV2", { modelDefinitions: [mobilenet.MobileNetV2Model] });
	})().catch((error) => {
		loading = null;
		throw error;
	});
	return loading;
}
async function toCanvas(file) {
	const bitmap = await createImageBitmap(file);
	const canvas = document.createElement("canvas");
	const scale = Math.min(1, 512 / Math.max(bitmap.width, bitmap.height));
	canvas.width = Math.max(1, Math.round(bitmap.width * scale));
	canvas.height = Math.max(1, Math.round(bitmap.height * scale));
	const ctx = canvas.getContext("2d");
	if (!ctx) {
		bitmap.close();
		throw new Error("No se pudo preparar la imagen");
	}
	ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
	bitmap.close();
	return canvas;
}
var LABELS = {
	Drawing: "Dibujo",
	Hentai: "Ilustración explícita",
	Neutral: "Neutra",
	Porn: "Explícita",
	Sexy: "Sugerente"
};
function labelFor(className) {
	return LABELS[className] ?? className;
}
async function classifyBlob(file) {
	const model = await loadLocalModel();
	const canvas = await toCanvas(file);
	return (await model.classify(canvas, 5)).map((item) => ({
		className: item.className,
		probability: item.probability
	}));
}
function decide(scores, settings) {
	const byName = Object.fromEntries(scores.map((score) => [score.className, score.probability]));
	const explicit = (byName.Porn ?? 0) + (byName.Hentai ?? 0);
	const sexy = byName.Sexy ?? 0;
	const top = [...scores].sort((a, b) => b.probability - a.probability)[0] ?? {
		className: "Neutral",
		probability: 0
	};
	const sexyWins = settings.treatSexy && top.className === "Sexy" && sexy >= settings.threshold;
	return {
		scores,
		explicit,
		sexy,
		top,
		nsfw: explicit >= settings.threshold || sexyWins,
		label: labelFor(top.className)
	};
}
var VERIFIER_TEXT = "linde-vault-v1";
var ITERATIONS = 21e4;
function copyBuffer(bytes) {
	const copy = new Uint8Array(bytes.byteLength);
	copy.set(bytes);
	return copy.buffer;
}
function randomBytes(length) {
	const bytes = new Uint8Array(length);
	crypto.getRandomValues(bytes);
	return bytes;
}
async function deriveKey(passphrase, salt) {
	const base = await crypto.subtle.importKey("raw", new TextEncoder().encode(passphrase), "PBKDF2", false, ["deriveKey"]);
	return crypto.subtle.deriveKey({
		name: "PBKDF2",
		salt: copyBuffer(salt),
		iterations: ITERATIONS,
		hash: "SHA-256"
	}, base, {
		name: "AES-GCM",
		length: 256
	}, false, ["encrypt", "decrypt"]);
}
async function encryptBytes(key, plain) {
	const iv = randomBytes(12);
	const cipher = await crypto.subtle.encrypt({
		name: "AES-GCM",
		iv: copyBuffer(iv)
	}, key, copyBuffer(plain));
	return {
		iv,
		data: new Uint8Array(cipher)
	};
}
async function decryptBytes(key, iv, data) {
	const plain = await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv: copyBuffer(iv)
	}, key, copyBuffer(data));
	return new Uint8Array(plain);
}
async function makeVerifier(key) {
	return encryptBytes(key, new TextEncoder().encode(VERIFIER_TEXT));
}
async function checkVerifier(key, iv, data) {
	try {
		const plain = await decryptBytes(key, iv, data);
		return new TextDecoder().decode(plain) === VERIFIER_TEXT;
	} catch {
		return false;
	}
}
/** Cabecera JSON + bytes de la imagen. El paquete entero se cifra; el nombre no queda en claro. */
function packPayload(meta, image) {
	const header = new TextEncoder().encode(JSON.stringify(meta));
	const out = new Uint8Array(4 + header.length + image.length);
	new DataView(out.buffer).setUint32(0, header.length, false);
	out.set(header, 4);
	out.set(image, 4 + header.length);
	return out;
}
function unpackPayload(packet) {
	const headerLength = new DataView(packet.buffer, packet.byteOffset, packet.byteLength).getUint32(0, false);
	const header = packet.slice(4, 4 + headerLength);
	const image = packet.slice(4 + headerLength);
	return {
		meta: JSON.parse(new TextDecoder().decode(header)),
		image
	};
}
var DB_NAME = "linde";
var DB_VERSION = 1;
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, DB_VERSION);
		req.onupgradeneeded = () => {
			const db = req.result;
			if (!db.objectStoreNames.contains("meta")) db.createObjectStore("meta");
			if (!db.objectStoreNames.contains("public")) db.createObjectStore("public", { keyPath: "id" });
			if (!db.objectStoreNames.contains("private")) db.createObjectStore("private", { keyPath: "id" });
			if (!db.objectStoreNames.contains("handles")) db.createObjectStore("handles");
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error ?? /* @__PURE__ */ new Error("No se pudo abrir el almacén local"));
	});
}
async function withStore(name, mode, run) {
	const db = await openDb();
	try {
		const tx = db.transaction(name, mode);
		const request = run(tx.objectStore(name));
		return await new Promise((resolve, reject) => {
			tx.oncomplete = () => resolve(request.result);
			tx.onabort = () => reject(tx.error ?? request.error ?? /* @__PURE__ */ new Error("Transacción abortada"));
			tx.onerror = () => reject(tx.error ?? request.error ?? /* @__PURE__ */ new Error("Transacción fallida"));
		});
	} finally {
		db.close();
	}
}
function readVaultMeta() {
	return withStore("meta", "readonly", (store) => store.get("vault")).then((row) => row ?? null);
}
function writeVaultMeta(meta) {
	return withStore("meta", "readwrite", (store) => store.put(meta, "vault"));
}
function readSeen() {
	return withStore("meta", "readonly", (store) => store.get("seen")).then((row) => row ?? []);
}
function writeSeen(seen) {
	return withStore("meta", "readwrite", (store) => store.put(seen.slice(-400), "seen"));
}
function listPublic() {
	return withStore("public", "readonly", (store) => store.getAll());
}
function putPublic(record) {
	return withStore("public", "readwrite", (store) => store.put(record));
}
function deletePublic(id) {
	return withStore("public", "readwrite", (store) => store.delete(id));
}
function listPrivate() {
	return withStore("private", "readonly", (store) => store.getAll());
}
function putPrivate(record) {
	return withStore("private", "readwrite", (store) => store.put(record));
}
function deletePrivate(id) {
	return withStore("private", "readwrite", (store) => store.delete(id));
}
function readHandle(kind) {
	return withStore("handles", "readonly", (store) => store.get(kind)).then((row) => row ?? null);
}
function writeHandle(kind, handle) {
	return withStore("handles", "readwrite", (store) => store.put(handle, kind));
}
function clearHandle(kind) {
	return withStore("handles", "readwrite", (store) => store.delete(kind));
}
async function wipeAll() {
	const db = await openDb();
	try {
		await new Promise((resolve, reject) => {
			const tx = db.transaction([
				"meta",
				"public",
				"private",
				"handles"
			], "readwrite");
			tx.objectStore("meta").clear();
			tx.objectStore("public").clear();
			tx.objectStore("private").clear();
			tx.objectStore("handles").clear();
			tx.oncomplete = () => resolve();
			tx.onerror = () => reject(tx.error ?? /* @__PURE__ */ new Error("No se pudo borrar"));
			tx.onabort = () => reject(tx.error ?? /* @__PURE__ */ new Error("No se pudo borrar"));
		});
	} finally {
		db.close();
	}
}
var defaultSettings = {
	threshold: .4,
	treatSexy: false,
	removeSource: false,
	watch: true
};
var KEY = "linde-settings";
function readSettings() {
	if (typeof localStorage === "undefined") return defaultSettings;
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return defaultSettings;
		const parsed = JSON.parse(raw);
		return {
			threshold: typeof parsed.threshold === "number" ? Math.min(.9, Math.max(.15, parsed.threshold)) : defaultSettings.threshold,
			treatSexy: Boolean(parsed.treatSexy),
			removeSource: Boolean(parsed.removeSource),
			watch: parsed.watch !== false
		};
	} catch {
		return defaultSettings;
	}
}
function writeSettings(settings) {
	localStorage.setItem(KEY, JSON.stringify(settings));
}
function formatBytes(bytes) {
	if (bytes < 1024) return `${bytes} B`;
	if (bytes < 1048576) return `${Math.round(bytes / 1024)} KB`;
	return `${(bytes / 1048576).toFixed(1)} MB`;
}
function formatWhen(at) {
	return new Intl.DateTimeFormat("es", {
		hour: "2-digit",
		minute: "2-digit"
	}).format(at);
}
async function sampleLandscape() {
	const canvas = document.createElement("canvas");
	canvas.width = 960;
	canvas.height = 640;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Sin lienzo");
	const sky = ctx.createLinearGradient(0, 0, 0, 420);
	sky.addColorStop(0, "#6f92a8");
	sky.addColorStop(1, "#e4d2b4");
	ctx.fillStyle = sky;
	ctx.fillRect(0, 0, 960, 640);
	ctx.fillStyle = "#3d5344";
	ctx.beginPath();
	ctx.moveTo(0, 390);
	ctx.lineTo(220, 250);
	ctx.lineTo(410, 360);
	ctx.lineTo(640, 200);
	ctx.lineTo(960, 340);
	ctx.lineTo(960, 640);
	ctx.lineTo(0, 640);
	ctx.fill();
	ctx.fillStyle = "#f4efe6";
	ctx.font = "600 64px Fraunces, Georgia, serif";
	ctx.fillText("Linde", 56, 120);
	ctx.font = "400 22px Outfit, sans-serif";
	ctx.fillText("Imagen de prueba · no sale del dispositivo", 56, 164);
	const blob = await new Promise((resolve, reject) => {
		canvas.toBlob((value) => value ? resolve(value) : reject(/* @__PURE__ */ new Error("JPEG")), "image/jpeg", .92);
	});
	return new File([blob], "prueba-linde.jpg", { type: "image/jpeg" });
}
async function ensurePermission(handle, write) {
	const mode = write ? "readwrite" : "read";
	if (await handle.queryPermission({ mode }) === "granted") return true;
	return await handle.requestPermission({ mode }) === "granted";
}
async function writeIntoFolder(dir, file) {
	const writable = await (await dir.getFileHandle(file.name, { create: true })).createWritable();
	await writable.write(file);
	await writable.close();
}
function LindeApp() {
	const [phase, setPhase] = (0, import_react.useState)("boot");
	const [modelState, setModelState] = (0, import_react.useState)("idle");
	const [modelError, setModelError] = (0, import_react.useState)("");
	const [settings, setSettings] = (0, import_react.useState)(defaultSettings);
	const [passphrase, setPassphrase] = (0, import_react.useState)("");
	const [passphraseAgain, setPassphraseAgain] = (0, import_react.useState)("");
	const [formError, setFormError] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [status, setStatus] = (0, import_react.useState)("Preparando el almacén local");
	const [publicItems, setPublicItems] = (0, import_react.useState)([]);
	const [vaultItems, setVaultItems] = (0, import_react.useState)([]);
	const [logs, setLogs] = (0, import_react.useState)([]);
	const [sourceName, setSourceName] = (0, import_react.useState)("");
	const [destName, setDestName] = (0, import_react.useState)("");
	const [dragging, setDragging] = (0, import_react.useState)(false);
	const [pane, setPane] = (0, import_react.useState)("inicio");
	const [folder, setFolder] = (0, import_react.useState)(null);
	const keyRef = (0, import_react.useRef)(null);
	const settingsRef = (0, import_react.useRef)(settings);
	const sourceRef = (0, import_react.useRef)(null);
	const destRef = (0, import_react.useRef)(null);
	const pendingRef = (0, import_react.useRef)([]);
	const scanningRef = (0, import_react.useRef)(false);
	const urlsRef = (0, import_react.useRef)([]);
	settingsRef.current = settings;
	const pushLog = (0, import_react.useCallback)((text, kind) => {
		setLogs((current) => [{
			id: crypto.randomUUID(),
			at: Date.now(),
			text,
			kind
		}, ...current].slice(0, 12));
	}, []);
	const rememberUrl = (0, import_react.useCallback)((url) => {
		urlsRef.current.push(url);
		return url;
	}, []);
	const releaseUrls = (0, import_react.useCallback)((urls) => {
		for (const url of urls) URL.revokeObjectURL(url);
		urlsRef.current = urlsRef.current.filter((url) => !urls.includes(url));
	}, []);
	const hydratePublic = (0, import_react.useCallback)((rows) => {
		setPublicItems((current) => {
			releaseUrls(current.map((item) => item.url));
			return rows.sort((a, b) => b.addedAt - a.addedAt).map((row) => ({
				...row,
				url: rememberUrl(URL.createObjectURL(row.blob))
			}));
		});
	}, [rememberUrl, releaseUrls]);
	const hydrateVault = (0, import_react.useCallback)((rows) => {
		setVaultItems((current) => {
			releaseUrls(current.flatMap((item) => item.url ? [item.url] : []));
			return rows.sort((a, b) => b.addedAt - a.addedAt).map((row) => ({
				id: row.id,
				addedAt: row.addedAt,
				bytes: row.bytes,
				revealed: false
			}));
		});
	}, [releaseUrls]);
	(0, import_react.useEffect)(() => {
		let cancelled = false;
		(async () => {
			try {
				const [meta, photos, sealed, source, dest] = await Promise.all([
					readVaultMeta(),
					listPublic(),
					listPrivate(),
					readHandle("source"),
					readHandle("dest")
				]);
				if (cancelled) return;
				hydratePublic(photos);
				hydrateVault(sealed);
				sourceRef.current = source;
				destRef.current = dest;
				setSourceName(source?.name ?? "");
				setDestName(dest?.name ?? "");
				setPhase(meta ? "locked" : "setup");
				setSettings(readSettings());
				setStatus(meta ? "Bóveda cerrada" : "Crea una frase para la bóveda");
			} catch (error) {
				if (cancelled) return;
				setPhase("setup");
				setFormError(error instanceof Error ? error.message : "No se pudo leer el almacén");
			}
		})();
		return () => {
			cancelled = true;
		};
	}, [hydratePublic, hydrateVault]);
	(0, import_react.useEffect)(() => {
		return () => {
			for (const url of urlsRef.current) URL.revokeObjectURL(url);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (phase !== "open") return;
		let cancelled = false;
		setModelState("loading");
		loadLocalModel().then(() => {
			if (cancelled) return;
			setModelState("ready");
			setStatus("Modelo local listo");
		}).catch((error) => {
			if (cancelled) return;
			setModelState("error");
			setModelError(error instanceof Error ? error.message : "No se pudo cargar el modelo");
		});
		return () => {
			cancelled = true;
		};
	}, [phase]);
	const ingestFiles = (0, import_react.useCallback)(async (files, source) => {
		const key = keyRef.current;
		if (!key) {
			pushLog("Desbloquea la bóveda antes de clasificar", "info");
			return;
		}
		if (modelState !== "ready") {
			pushLog("El modelo todavía se está preparando", "info");
			return;
		}
		const images = files.filter((file) => file.type.startsWith("image/") || /\.(jpe?g|png|webp|gif|bmp)$/i.test(file.name));
		if (images.length === 0) {
			pushLog("No había imágenes en la selección", "info");
			return;
		}
		setBusy(true);
		const currentSettings = settingsRef.current;
		let safeCount = 0;
		let vaultCount = 0;
		try {
			for (const file of images) {
				setStatus(`Clasificando ${file.name}`);
				const buffer = new Uint8Array(await file.arrayBuffer());
				const scores = await classifyBlob(file);
				const decision = decide(scores, currentSettings);
				if (decision.nsfw) {
					const sealed = await encryptBytes(key, packPayload({
						name: file.name,
						mime: file.type || "image/jpeg",
						scores
					}, buffer));
					await putPrivate({
						id: crypto.randomUUID(),
						addedAt: Date.now(),
						bytes: buffer.byteLength,
						iv: sealed.iv,
						data: sealed.data
					});
					vaultCount += 1;
					pushLog("Imagen explícita cifrada con AES-256-GCM", "vault");
				} else {
					await putPublic({
						id: crypto.randomUUID(),
						name: file.name,
						mime: file.type || "image/jpeg",
						addedAt: Date.now(),
						bytes: buffer.byteLength,
						scores,
						blob: new Blob([buffer], { type: file.type || "image/jpeg" })
					});
					safeCount += 1;
					const top = decision.top;
					pushLog(`${file.name} → biblioteca · ${labelFor(top.className)} ${Math.round(top.probability * 100)}%`, "safe");
					const dest = destRef.current;
					if (dest) try {
						if (await ensurePermission(dest, true)) await writeIntoFolder(dest, file);
					} catch {
						pushLog(`No se pudo copiar ${file.name} a la carpeta pública`, "error");
					}
				}
				if (currentSettings.removeSource && source) try {
					await source.removeEntry(file.name);
				} catch {
					pushLog(`No se pudo retirar ${file.name} del origen`, "error");
				}
			}
			hydratePublic(await listPublic());
			hydrateVault(await listPrivate());
			setStatus(vaultCount > 0 ? `${safeCount} a la biblioteca · ${vaultCount} a la bóveda` : `${safeCount} imagen${safeCount === 1 ? "" : "es"} en la biblioteca`);
		} catch (error) {
			pushLog(error instanceof Error ? error.message : "Falló la clasificación", "error");
			setStatus("Clasificación interrumpida");
		} finally {
			setBusy(false);
		}
	}, [
		hydratePublic,
		hydrateVault,
		modelState,
		pushLog
	]);
	const scanSource = (0, import_react.useCallback)(async () => {
		const dir = sourceRef.current;
		const key = keyRef.current;
		if (!dir || !key || modelState !== "ready" || scanningRef.current) return;
		scanningRef.current = true;
		try {
			if (!await ensurePermission(dir, settingsRef.current.removeSource)) {
				pushLog("Sin permiso para leer la carpeta vigilada", "error");
				return;
			}
			const seen = new Set(await readSeen());
			const fresh = [];
			const signatures = [];
			for await (const [name, handle] of dir.entries()) {
				if (handle.kind !== "file") continue;
				if (!/\.(jpe?g|png|webp|gif|bmp)$/i.test(name)) continue;
				const file = await handle.getFile();
				const signature = `${name}:${file.size}:${file.lastModified}`;
				if (seen.has(signature)) continue;
				fresh.push(file);
				signatures.push(signature);
			}
			if (fresh.length === 0) return;
			pushLog(`${fresh.length} imagen${fresh.length === 1 ? "" : "es"} nueva${fresh.length === 1 ? "" : "s"} en la carpeta`, "info");
			await ingestFiles(fresh, settingsRef.current.removeSource ? dir : null);
			signatures.forEach((signature) => seen.add(signature));
			await writeSeen([...seen]);
		} catch (error) {
			pushLog(error instanceof Error ? error.message : "No se pudo vigilar la carpeta", "error");
		} finally {
			scanningRef.current = false;
		}
	}, [
		ingestFiles,
		modelState,
		pushLog
	]);
	(0, import_react.useEffect)(() => {
		if (phase !== "open" || modelState !== "ready" || pendingRef.current.length === 0) return;
		const batch = pendingRef.current.splice(0);
		ingestFiles(batch);
	}, [
		ingestFiles,
		modelState,
		phase
	]);
	(0, import_react.useEffect)(() => {
		if (phase !== "open" || !settings.watch || modelState !== "ready") return;
		const tick = () => {
			if (document.visibilityState !== "visible") return;
			scanSource();
		};
		tick();
		const id = window.setInterval(tick, 2e4);
		document.addEventListener("visibilitychange", tick);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", tick);
		};
	}, [
		modelState,
		phase,
		scanSource,
		settings.watch
	]);
	function updateSettings(next) {
		setSettings(next);
		writeSettings(next);
	}
	async function createVault(event) {
		event.preventDefault();
		setFormError("");
		if (passphrase.length < 8) {
			setFormError("Usa al menos 8 caracteres.");
			return;
		}
		if (passphrase !== passphraseAgain) {
			setFormError("Las frases no coinciden.");
			return;
		}
		setBusy(true);
		try {
			const salt = randomBytes(16);
			const key = await deriveKey(passphrase, salt);
			const verifier = await makeVerifier(key);
			await writeVaultMeta({
				salt,
				iv: verifier.iv,
				verifier: verifier.data
			});
			keyRef.current = key;
			setPassphrase("");
			setPassphraseAgain("");
			setPhase("open");
			setStatus("Bóveda creada en este dispositivo");
			pushLog("Clave derivada con PBKDF2 y comprobada. No se guarda la frase.", "info");
		} catch (error) {
			setFormError(error instanceof Error ? error.message : "No se pudo crear la bóveda");
		} finally {
			setBusy(false);
		}
	}
	async function unlock(event) {
		event.preventDefault();
		setFormError("");
		setBusy(true);
		try {
			const meta = await readVaultMeta();
			if (!meta) {
				setPhase("setup");
				return;
			}
			const key = await deriveKey(passphrase, meta.salt);
			if (!await checkVerifier(key, meta.iv, meta.verifier)) {
				setFormError("Frase incorrecta.");
				return;
			}
			keyRef.current = key;
			setPassphrase("");
			setPhase("open");
			setStatus("Bóveda abierta en memoria");
		} catch (error) {
			setFormError(error instanceof Error ? error.message : "No se pudo abrir");
		} finally {
			setBusy(false);
		}
	}
	function lock() {
		keyRef.current = null;
		setVaultItems((current) => {
			releaseUrls(current.flatMap((item) => item.url ? [item.url] : []));
			return current.map((item) => ({
				id: item.id,
				addedAt: item.addedAt,
				bytes: item.bytes,
				revealed: false
			}));
		});
		setPhase("locked");
		setStatus("Bóveda cerrada. La clave ya no está en memoria.");
	}
	async function pickFolder(kind) {
		const picker = window.showDirectoryPicker;
		if (!picker) {
			pushLog("Este navegador no deja elegir carpetas. Arrastra las fotos.", "info");
			return;
		}
		try {
			const handle = await picker({
				mode: kind === "dest" || settings.removeSource ? "readwrite" : "read",
				id: kind === "source" ? "linde-source" : "linde-dest"
			});
			await writeHandle(kind, handle);
			if (kind === "source") {
				sourceRef.current = handle;
				setSourceName(handle.name);
				pushLog(`Vigilando “${handle.name}”`, "info");
				if (phase === "open") scanSource();
			} else {
				destRef.current = handle;
				setDestName(handle.name);
				pushLog(`Las fotos neutras también se copian a “${handle.name}”`, "info");
			}
		} catch (error) {
			if (error instanceof DOMException && error.name === "AbortError") return;
			pushLog(error instanceof Error ? error.message : "No se pudo elegir la carpeta", "error");
		}
	}
	async function forgetFolder(kind) {
		await clearHandle(kind);
		if (kind === "source") {
			sourceRef.current = null;
			setSourceName("");
		} else {
			destRef.current = null;
			setDestName("");
		}
	}
	async function onPickFiles(list) {
		if (!list) return;
		const batch = Array.from(list);
		if (phase !== "open" || !keyRef.current) {
			pushLog("Desbloquea la bóveda para clasificar", "info");
			return;
		}
		if (modelState !== "ready") {
			pendingRef.current.push(...batch);
			pushLog("En cola. Empieza sola cuando el modelo local esté listo.", "info");
			return;
		}
		await ingestFiles(batch);
	}
	async function runSample() {
		if (phase !== "open") return;
		const file = await sampleLandscape();
		await ingestFiles([file]);
	}
	async function removePublic(item) {
		URL.revokeObjectURL(item.url);
		await deletePublic(item.id);
		setPublicItems((current) => current.filter((row) => row.id !== item.id));
	}
	function downloadPublic(item) {
		const anchor = document.createElement("a");
		anchor.href = item.url;
		anchor.download = item.name;
		anchor.click();
	}
	async function toggleVault(item) {
		if (item.url) {
			setVaultItems((current) => current.map((row) => row.id === item.id ? {
				...row,
				revealed: !row.revealed
			} : row));
			return;
		}
		const key = keyRef.current;
		if (!key) return;
		const row = (await listPrivate()).find((candidate) => candidate.id === item.id);
		if (!row) return;
		try {
			const unpacked = unpackPayload(await decryptBytes(key, row.iv, row.data));
			const blob = new Blob([new Uint8Array(unpacked.image)], { type: unpacked.meta.mime });
			const url = rememberUrl(URL.createObjectURL(blob));
			const top = [...unpacked.meta.scores].sort((a, b) => b.probability - a.probability)[0];
			setVaultItems((current) => current.map((entry) => entry.id === item.id ? {
				...entry,
				url,
				name: unpacked.meta.name,
				label: top ? labelFor(top.className) : "Cifrada",
				revealed: true
			} : entry));
		} catch {
			pushLog("No se pudo descifrar esa entrada", "error");
		}
	}
	async function removeVault(id) {
		const current = vaultItems.find((item) => item.id === id);
		if (current?.url) URL.revokeObjectURL(current.url);
		await deletePrivate(id);
		setVaultItems((rows) => rows.filter((row) => row.id !== id));
	}
	async function eraseEverything() {
		if (!window.confirm("Esto borra la frase, la biblioteca y la bóveda de este navegador. No se puede deshacer.")) return;
		await wipeAll();
		keyRef.current = null;
		sourceRef.current = null;
		destRef.current = null;
		releaseUrls(urlsRef.current.slice());
		setPublicItems([]);
		setVaultItems([]);
		setLogs([]);
		setSourceName("");
		setDestName("");
		setPhase("setup");
		setStatus("Almacén local vacío");
	}
	const counts = (0, import_react.useMemo)(() => ({
		public: publicItems.length,
		vault: vaultItems.length
	}), [publicItems.length, vaultItems.length]);
	const screen = pane === "ajustes" ? "ajustes" : pane === "biblioteca" ? "biblioteca" : pane === "boveda" ? "boveda" : folder ?? "grid";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "pointer-events-none absolute inset-0 overflow-hidden",
				"aria-hidden": "true",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -top-20 -left-10 size-72 rounded-full bg-orb-blue/50" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-40 -right-16 size-64 rounded-full bg-orb-copper/45" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute bottom-8 left-8 size-56 rounded-full bg-orb-green/40" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "glass relative min-h-dvh border-0",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
					className: "mx-auto min-h-dvh max-w-5xl px-4 pt-8 pb-32 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
						className: "flex items-end justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs tracking-widest text-muted uppercase",
							children: "Archivo local"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl font-medium tracking-tight",
							children: "Linde"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-xs text-right text-sm text-muted",
							children: status
						})]
					}), screen === "grid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mt-8",
						"aria-label": "Carpetas",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm text-muted",
							children: "Elige una carpeta"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderCard, {
									name: "Entrada",
									detail: "Clasificar",
									count: null,
									onOpen: () => setFolder("entrada")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderCard, {
									name: "Biblioteca",
									detail: "Públicas",
									count: counts.public,
									onOpen: () => setFolder("biblioteca")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderCard, {
									name: "Bóveda",
									detail: "Cifradas",
									count: counts.vault,
									onOpen: () => setFolder("boveda")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderCard, {
									name: "Registro",
									detail: "Movimientos",
									count: logs.length,
									onOpen: () => setFolder("registro")
								})
							]
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6",
						children: [
							pane === "inicio" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setFolder(null),
								className: "mb-4 h-11 text-sm text-muted",
								children: "Inicio"
							}) : null,
							screen === "entrada" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "glass rounded-card p-4 text-fg sm:p-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl",
										children: "Entrada"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm text-muted",
										children: "Suelta fotos. Lo neutro queda en la biblioteca. Lo explícito se cifra."
									}),
									phase === "boot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-6 text-sm",
										children: "Abriendo el almacén…"
									}) : null,
									phase === "setup" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										className: "mt-5 grid gap-3",
										onSubmit: createVault,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Frase de la bóveda",
												value: passphrase,
												onChange: setPassphrase,
												autoComplete: "new-password"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Repite la frase",
												value: passphraseAgain,
												onChange: setPassphraseAgain,
												autoComplete: "new-password"
											}),
											formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-copper",
												children: formError
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "submit",
												disabled: busy,
												className: "inline-flex h-12 items-center justify-center rounded-2xl bg-fg px-4 text-sm font-medium text-bg disabled:opacity-60",
												children: "Crear bóveda"
											})
										]
									}) : null,
									phase === "locked" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
										className: "mt-5 grid gap-3",
										onSubmit: unlock,
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Frase",
												value: passphrase,
												onChange: setPassphrase,
												autoComplete: "current-password"
											}),
											formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-copper",
												children: formError
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "submit",
												disabled: busy,
												className: "inline-flex h-12 items-center justify-center rounded-2xl bg-fg px-4 text-sm font-medium text-bg disabled:opacity-60",
												children: "Abrir para clasificar"
											})
										]
									}) : null,
									phase === "open" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-5 grid gap-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												onDragOver: (event) => {
													event.preventDefault();
													setDragging(true);
												},
												onDragLeave: () => setDragging(false),
												onDrop: (event) => {
													event.preventDefault();
													setDragging(false);
													onPickFiles(event.dataTransfer.files);
												},
												className: "flex min-h-28 cursor-pointer flex-col items-center justify-center gap-2 rounded-card border border-dashed px-3 py-4 text-center text-sm " + (dragging ? "border-fg" : "border-line"),
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {
														className: "size-5",
														"aria-hidden": "true"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Arrastra imágenes o elige archivos" }),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
														type: "file",
														accept: "image/*",
														multiple: true,
														className: "sr-only",
														onChange: (event) => {
															onPickFiles(event.target.files);
															event.target.value = "";
														}
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "grid gap-2 sm:grid-cols-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => void runSample(),
													disabled: busy || modelState !== "ready",
													className: "inline-flex h-11 items-center justify-center rounded-2xl bg-sage px-3 text-sm font-medium text-sage-ink disabled:opacity-60",
													children: "Probar con un paisaje"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													onClick: () => void scanSource(),
													disabled: busy || !sourceName || modelState !== "ready",
													className: "inline-flex h-11 items-center justify-center rounded-2xl border border-line px-3 text-sm font-medium disabled:opacity-50",
													children: "Revisar carpeta"
												})]
											}),
											modelState === "error" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-copper",
												children: modelError
											}) : null,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: lock,
												className: "inline-flex h-11 items-center justify-center text-sm text-muted",
												children: "Cerrar bóveda"
											})
										]
									}) : null
								]
							}) : null,
							screen === "biblioteca" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: "Biblioteca"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: "Fotos que no superaron el umbral."
								}),
								publicItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm text-muted",
									children: "Todavía no hay fotos públicas."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3",
									children: publicItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "glass overflow-hidden rounded-card",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
											src: item.url,
											alt: item.name,
											className: "aspect-square w-full object-cover"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-2 p-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "truncate text-sm",
													children: item.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-xs text-muted",
													children: [
														labelFor(item.scores[0]?.className ?? "Neutral"),
														" · ",
														formatBytes(item.bytes)
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
														label: `Descargar ${item.name}`,
														onClick: () => downloadPublic(item),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
														label: `Quitar ${item.name}`,
														onClick: () => void removePublic(item),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
													})]
												})
											]
										})]
									}, item.id))
								})
							] }) : null,
							screen === "boveda" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-2xl",
									children: "Bóveda"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: "AES-256-GCM. El nombre va dentro del cifrado."
								}),
								vaultItems.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 text-sm text-muted",
									children: "La bóveda está vacía."
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3",
									children: vaultItems.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "glass overflow-hidden rounded-card",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "relative aspect-square",
											children: item.url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
												src: item.url,
												alt: item.revealed ? item.name ?? "Imagen cifrada" : "",
												className: "aspect-square w-full object-cover " + (item.revealed ? "" : "scale-110 blur-xl")
											}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "flex h-full items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, {
													className: "size-6 text-copper",
													"aria-hidden": "true"
												})
											})
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid gap-2 p-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "truncate text-sm",
													children: item.revealed ? item.name : "Cifrada"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "text-xs text-muted",
													children: [
														item.label ?? "Sin descifrar",
														" · ",
														formatBytes(item.bytes)
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
														label: item.revealed ? "Ocultar imagen" : "Descifrar y mostrar",
														onClick: () => void toggleVault(item),
														disabled: phase !== "open",
														children: item.revealed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
														label: "Borrar de la bóveda",
														onClick: () => void removeVault(item.id),
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
													})]
												})
											]
										})]
									}, item.id))
								})
							] }) : null,
							screen === "registro" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: "Registro"
							}), logs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Las explícitas no muestran el nombre."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-4 grid gap-2",
								children: logs.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "glass flex items-baseline justify-between gap-3 rounded-2xl px-3 py-3 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: line.kind === "vault" || line.kind === "error" ? "text-copper" : line.kind === "safe" ? "text-sage" : "text-fg",
										children: line.text
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
										className: "shrink-0 text-xs text-muted",
										dateTime: new Date(line.at).toISOString(),
										children: formatWhen(line.at)
									})]
								}, line.id))
							})] }) : null,
							screen === "ajustes" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "grid gap-4 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl",
										children: "Ajustes"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "glass grid gap-3 rounded-card p-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderRow, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderInput, {
													className: "size-4",
													"aria-hidden": "true"
												}),
												title: "Carpeta vigilada",
												name: sourceName,
												onPick: () => void pickFolder("source"),
												onClear: sourceName ? () => void forgetFolder("source") : void 0
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderRow, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOutput, {
													className: "size-4",
													"aria-hidden": "true"
												}),
												title: "Copia pública",
												name: destName,
												onPick: () => void pickFolder("dest"),
												onClear: destName ? () => void forgetFolder("dest") : void 0
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
												className: "grid gap-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "flex items-center justify-between",
													children: ["Umbral explícito", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "tabular-nums",
														children: [Math.round(settings.threshold * 100), "%"]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "range",
													min: .15,
													max: .9,
													step: .05,
													value: settings.threshold,
													onChange: (event) => updateSettings({
														...settings,
														threshold: Number(event.target.value)
													})
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
												checked: settings.treatSexy,
												label: "Cifrar también si domina “sugerente”",
												onChange: (treatSexy) => updateSettings({
													...settings,
													treatSexy
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
												checked: settings.watch,
												label: "Revisar al abrir y con la pestaña visible",
												onChange: (watch) => updateSettings({
													...settings,
													watch
												})
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
												checked: settings.removeSource,
												label: "Retirar del origen después de clasificar",
												onChange: (removeSource) => updateSettings({
													...settings,
													removeSource
												})
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-muted",
										children: [
											"En Android el mismo vidrio está en el proyecto Flutter, con",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-fg",
												children: "cupertino_liquid_glass"
											}),
											".",
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												className: "text-sage underline underline-offset-2",
												href: "/linde-android.zip",
												download: true,
												children: "Descargar"
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => void eraseEverything(),
										className: "h-11 text-left text-copper",
										children: "Borrar la bóveda de este navegador"
									})
								]
							}) : null
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "glass-bar fixed inset-x-3 bottom-3 z-10 mx-auto flex max-w-lg items-stretch justify-between rounded-full px-2 py-1",
				"aria-label": "Secciones",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BarButton, {
						active: pane === "inicio" && screen === "grid",
						label: "Inicio",
						onClick: () => {
							setPane("inicio");
							setFolder(null);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BarButton, {
						active: screen === "biblioteca",
						label: "Biblioteca",
						onClick: () => {
							setPane("biblioteca");
							setFolder(null);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BarButton, {
						active: screen === "boveda",
						label: "Bóveda",
						onClick: () => {
							setPane("boveda");
							setFolder(null);
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BarButton, {
						active: screen === "ajustes",
						label: "Ajustes",
						onClick: () => {
							setPane("ajustes");
							setFolder(null);
						}
					})
				]
			})
		]
	});
}
function FolderCard({ name, detail, count, onOpen }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: "glass flex aspect-square w-full flex-col items-start justify-between rounded-card p-4 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs tracking-wide text-muted uppercase",
			children: detail
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "block text-xl font-medium",
			children: name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-muted",
			children: count === null ? "Abrir" : count
		})] })]
	}) });
}
function BarButton({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "flex h-14 min-w-16 flex-1 flex-col items-center justify-center rounded-full text-xs " + (active ? "bg-fg/10 font-medium text-fg" : "text-muted"),
		children: label
	});
}
function Field({ label, value, onChange, autoComplete }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "grid gap-1 text-sm",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "password",
			value,
			autoComplete,
			onChange: (event) => onChange(event.target.value),
			className: "h-12 rounded-2xl border border-line bg-bg/40 px-3 text-fg"
		})]
	});
}
function Toggle({ checked, label, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex items-start gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type: "checkbox",
			checked,
			onChange: (event) => onChange(event.target.checked),
			className: "mt-1 size-4 accent-sage"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label })]
	});
}
function FolderRow({ icon, title, name, onPick, onClear }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center justify-between gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "flex items-center gap-2 font-medium text-fg",
				children: [icon, title]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-muted",
				children: name || "Sin elegir"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex shrink-0 gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onPick,
				className: "h-11 rounded-2xl border border-line px-3 text-fg",
				children: "Elegir"
			}), onClear ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onClear,
				className: "h-11 px-2 text-muted",
				children: "Quitar"
			}) : null]
		})]
	});
}
function IconButton({ label, onClick, disabled, light, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-label": label,
		title: label,
		disabled,
		onClick,
		className: "inline-flex size-11 items-center justify-center rounded-md disabled:opacity-40 " + (light ? "bg-paper/10 text-paper" : "bg-bg text-fg"),
		children
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LindeApp, {});
}
//#endregion
export { Home as component };
